import { createHash } from "node:crypto";
import { readFileSync, statSync } from "node:fs";
import type { ChatChunk, ChatMessage, NativeToolCall, Provider, ReasoningEffort, ToolSchema } from "../types.js";
import type { ActiveFile } from "../session/log.js";
import type { SideEffects, ToolResult } from "./tools/types.js";
import { estMessagesTokens, estTokens, getModelMeta } from "../lib/model-meta.js";
import { compactMessages, DEFAULT_COMPACTION_CONFIG, type CompactionConfig } from "./compaction.js";
import { isLoopExempt, isReadOnlyToolCall, toolCallFingerprint } from "./guards.js";
import { boundToolMessage } from "./limits.js";
import { pairToolMessages } from "../session/projection.js";
import { isNativeUnsupportedError, isToolPairingError, type ToolProtocol } from "./protocol-mode.js";
import type { ApprovalResolver } from "./approval.js";
import { formatToolResults, parseToolCalls, stripToolCalls, systemPromptForFallback } from "./protocol.js";
import { runStream } from "./stream.js";
import { runAgentTool } from "./tools.js";

export interface ToolCall {
    tool: string;
    [key: string]: any;
}

export interface LoopDetectionOptions {
    readOnlyThreshold?: number;
    sideEffectThreshold?: number;
    window?: number;
    exemptReadOnly?: boolean;
}

export interface RunOptions {
    provider: Provider;
    apiKey?: string;
    model: string;
    messages?: ChatMessage[];
    prompt: string;
    system?: string;
    maxTurns?: number;
    allowTools?: boolean;
    tokenBudget?: number;
    costBudgetUsd?: number;
    signal?: AbortSignal;
    cwd?: string;
    idleTimeoutMs?: number;
    compaction?: CompactionConfig;
    contextWindow?: number;
    serverOpaqueState?: string;
    loopDetection?: LoopDetectionOptions;
    reasoningEffort?: ReasoningEffort;
    protocol?: ToolProtocol;
    tools?: ToolSchema[];
    onProtocolFallback?: (message: string) => void;
    onNativeOk?: () => void;
    takeSteering?: () => string[];
    onDelta?: (delta: string, text: string) => void;
    requestApproval?: ApprovalResolver;
}

export type AgentStopReason =
    | "complete"
    | "max_turns"
    | "token_budget"
    | "cost_budget"
    | "loop_detected"
    | "aborted"
    | "incomplete"
    | "stream_error"
    | "protocol_error";

export type AgentErrorKind = "token_budget" | "cost_budget" | "loop_detected" | "aborted" | "stream_error" | "protocol_error" | "incomplete";

export type AgentEvent =
    | {
        type: "compaction";
        beforeChars: number;
        afterChars: number;
        beforeTokens: number;
        afterTokens: number;
        droppedMessages: number;
        keptMessages: number;
        reason: "threshold" | "heap";
        source: "local" | "server";
        summaryFile?: string;
    }
    | { type: "assistant_raw"; text: string; toolCalls?: NativeToolCall[]; reasoning?: string }
    | { type: "assistant_text"; text: string }
    | { type: "tool_call"; id: string; call: ToolCall; native?: boolean }
    | { type: "tool_result"; id: string; call: ToolCall; ok: boolean; output: string; sideEffects?: SideEffects; code?: string; hint?: string; truncated?: boolean; totalLines?: number; returnedLines?: number; totalBytes?: number; returnedBytes?: number; filesRead?: number; filesSkipped?: number; matches?: number }
    | { type: "egress_denied"; outlet: string; target?: string; rule: string; mode: "audit" | "block"; wouldBlock: boolean; code: "EGRESS_DENY"; reason: string }
    | { type: "usage"; usage: NonNullable<ChatChunk["usage"]> }
    | { type: "loop_detected"; fingerprint: string; occurrences: number; warned: boolean }
    | { type: "notice"; text: string }
    | { type: "error"; kind: AgentErrorKind; message: string; text?: string; used?: number }
    | { type: "checkpoint"; turn: number; cwd: string; providerId: string; model: string; activeFiles: ActiveFile[] }
    | { type: "done"; history: ChatMessage[]; finalText: string; stopReason: AgentStopReason };

export const LOOP_WARNING = "[loop detection] You appear to be repeating the same tool call. " +
    "Do not repeat it again: inspect the result you already have, or change approach.";

interface LoopVerdict {
    action: "ok" | "warn" | "stop";
    occurrences: number;
}

/**
 * Sliding-window loop detector.
 *
 * Semantics (fixed by FC-004, do not re-interpret):
 * - hits count the last `window` tool calls, not turns;
 * - read-only tools use a higher threshold than side-effecting tools (D-02);
 * - the first threshold hit yields a warning and resets that fingerprint's count;
 * - only a second full accumulation yields a terminal error;
 * - the table lives for one run (turn), so a new user task starts clean;
 * - fingerprints are normalized per tool call (absolute paths, timeoutMs removed).
 */
class LoopState {
    private entries = new Map<string, { warned: boolean; hits: number[] }>();
    private calls = 0;
    private readonly readOnlyThreshold: number;
    private readonly sideEffectThreshold: number;
    private readonly window: number;
    private readonly exemptReadOnly: boolean;
    constructor(options: LoopDetectionOptions = {}) {
        this.window = positive(options.window, 5);
        // A threshold above the window can never be reached: the sliding
        // window keeps at most `window` hits, so clamp both thresholds.
        this.readOnlyThreshold = Math.min(positive(options.readOnlyThreshold, 5), this.window);
        this.sideEffectThreshold = Math.min(positive(options.sideEffectThreshold, 3), this.window);
        this.exemptReadOnly = options.exemptReadOnly === true;
    }
    check(fingerprint: string, readOnly: boolean): LoopVerdict {
        if (readOnly && this.exemptReadOnly)
            return { action: "ok", occurrences: 0 };
        this.calls += 1;
        const index = this.calls;
        let entry = this.entries.get(fingerprint);
        if (!entry) {
            entry = { warned: false, hits: [] };
            this.entries.set(fingerprint, entry);
        }
        entry.hits = entry.hits.filter((hit) => index - hit < this.window);
        entry.hits.push(index);
        const threshold = readOnly ? this.readOnlyThreshold : this.sideEffectThreshold;
        if (entry.hits.length < threshold)
            return { action: "ok", occurrences: entry.hits.length };
        const occurrences = entry.hits.length;
        if (!entry.warned) {
            entry.warned = true;
            entry.hits = [];
            return { action: "warn", occurrences };
        }
        return { action: "stop", occurrences };
    }
}

export async function* runAgent(options: RunOptions): AsyncGenerator<AgentEvent, void, void> {
    const provider = options.provider;
    const model = options.model;
    const cwd = options.cwd ?? process.cwd();
    const signal = options.signal;
    const maxTurns = Math.max(1, Math.floor(positive(options.maxTurns, 8)));
    const tokenBudget = optionalPositive(options.tokenBudget);
    const costBudget = optionalPositive(options.costBudgetUsd);
    const loop = new LoopState(options.loopDetection);
    let history: ChatMessage[] = [...(options.messages ?? []), { role: "user", content: options.prompt }];
    let currentText = "";
    let lastVisible = "";
    let consumedInput = 0;
    let spentCost = 0;
    let stopReason: AgentStopReason = "complete";
    let errorMessage = "";
    let protocolErrors = 0;
    // Fingerprints of broken markup already re-emitted once; a repeat means the
    // model is not going to recover, so stop instead of burning every turn.
    const protocolReemit = new Set<string>();
    let naturalFinish = false;
    let toolCallSeq = 0;
    let protocol: ToolProtocol = options.protocol ?? "legacy";
    let fellBack = false;
    let pairRetried = false;
    let activeSystem = options.system;
    const activeFiles = new Map<string, ActiveFile>();
    for (let turn = 0; turn < maxTurns; turn += 1) {
        if (signal?.aborted) {
            stopReason = "aborted";
            break;
        }
        for (const steering of options.takeSteering?.() ?? []) {
            history = [...history, { role: "system", content: "[user steering] " + steering }];
            yield { type: "notice", text: "Steering applied to the next request." };
        }
        // A dangling assistant(tool_calls) makes every subsequent request a
        // 400 ("tool messages must follow"). Repair before building the body so
        // aborts/loop stops can never poison the history.
        const paired = pairToolMessages(history);
        if (paired.repaired)
            history = paired.messages;
        const contextWindow = options.contextWindow ?? getModelMeta(provider.id, model).contextWindow;
        const compacted = compactMessages(history, options.compaction ?? DEFAULT_COMPACTION_CONFIG, {
            contextWindow,
            providerId: provider.id,
            model,
            serverOpaqueState: options.serverOpaqueState,
        });
        if (compacted.compacted) {
            history = compacted.messages;
            yield {
                type: "compaction",
                beforeChars: compacted.beforeChars,
                afterChars: compacted.afterChars,
                beforeTokens: compacted.beforeTokens,
                afterTokens: compacted.afterTokens,
                droppedMessages: compacted.droppedMessages,
                keptMessages: compacted.keptMessages,
                reason: compacted.reason ?? "threshold",
                source: compacted.source === "server" ? "server" : "local",
                summaryFile: compacted.summaryFile,
            };
        }
        const promptTokens = estMessagesTokens(history, { providerId: provider.id, model }) +
            estTokens(activeSystem ?? "", { providerId: provider.id, model });
        if (tokenBudget !== undefined && consumedInput + promptTokens > tokenBudget) {
            stopReason = "token_budget";
            errorMessage = `Token budget exhausted (${consumedInput + promptTokens} > ${tokenBudget} estimated input tokens). Partial output is kept.`;
            yield { type: "error", kind: "token_budget", message: errorMessage, text: lastVisible, used: consumedInput + promptTokens };
            break;
        }
        if (costBudget !== undefined && spentCost >= costBudget) {
            stopReason = "cost_budget";
            errorMessage = `Cost budget exhausted ($${spentCost.toFixed(4)} of $${costBudget}). Partial output is kept.`;
            yield { type: "error", kind: "cost_budget", message: errorMessage, text: lastVisible };
            break;
        }
        currentText = "";
        let resetNotice = "";
        let streamed;
        try {
            streamed = await runStream(provider, {
                model,
                messages: history,
                system: activeSystem,
                reasoningEffort: options.reasoningEffort,
                ...(protocol === "native" && options.tools && options.tools.length > 0 ? { tools: options.tools } : {}),
            }, options.apiKey, {
                signal,
                idleTimeoutMs: options.idleTimeoutMs,
                onDelta: (delta, text) => {
                    currentText = text;
                    options.onDelta?.(delta, text);
                },
                onReset: () => {
                    resetNotice = "Retried stream returned different content; the earlier partial output was discarded and replaced by the new stream.";
                },
            });
        }
        catch (err) {
            if (err?.name === "AbortError" || signal?.aborted) {
                stopReason = "aborted";
                break;
            }
            errorMessage = String(err?.message ?? err);
            if (protocol === "native" && !pairRetried && isToolPairingError(errorMessage)) {
                pairRetried = true;
                history = pairToolMessages(history).messages;
                yield { type: "notice", text: "Tool history was repaired after a pairing 400; retrying on the same protocol." };
                continue;
            }
            if (protocol === "native" && !fellBack && isNativeUnsupportedError(errorMessage)) {
                fellBack = true;
                protocol = "legacy";
                activeSystem = systemPromptForFallback(activeSystem);
                options.onProtocolFallback?.(`Native tools were rejected (${errorMessage.slice(0, 160)}); retrying with the pseudo protocol.`);
                turn -= 1;
                continue;
            }
            stopReason = "stream_error";
            const partial = stripToolCalls(String((err as { partialText?: string })?.partialText ?? "")).trim();
            // Reset, don't keep: a 402 before the first byte has no partial, and
            // reusing the previous turn's text wrote a stale assistant message.
            lastVisible = partial;
            yield { type: "error", kind: "stream_error", message: errorMessage, text: partial || undefined };
            break;
        }
        if (signal?.aborted) {
            stopReason = "aborted";
            break;
        }
        if (resetNotice)
            yield { type: "notice", text: resetNotice };
        if (streamed.retried > 0)
            yield { type: "notice", text: `Network stream was interrupted; retried ${streamed.retried} time(s).` };
        for (const warning of streamed.warnings ?? [])
            yield { type: "notice", text: warning };
        if (streamed.usage) {
            consumedInput += streamed.usage.inputTokens ?? promptTokens;
            spentCost += streamed.usage.costUsd ?? 0;
            yield { type: "usage", usage: streamed.usage };
        }
        else {
            consumedInput += promptTokens;
        }
        if (streamed.incomplete) {
            const partial = stripToolCalls(streamed.text).trim();
            if (partial)
                lastVisible = partial;
            stopReason = "incomplete";
            errorMessage = `Connection ended before the response finished${streamed.retried > 0 ? ` (retried ${streamed.retried}×)` : ""}. ` +
                "Partial output is kept — type 继续 to continue.";
            yield { type: "notice", text: errorMessage };
            // Terminal state gets both a notice (kept in the transcript) and an
            // error event so headless/JSON consumers see a non-complete stop
            // without inferring it from the notice text.
            yield { type: "error", kind: "incomplete", message: errorMessage, text: partial || undefined };
            yield { type: "checkpoint", turn: turn + 1, cwd, providerId: provider.id, model, activeFiles: Array.from(activeFiles.values()) };
            break;
        }
        // Native turns are schema-driven; text markup is ordinary content and
        // must not be parsed or silently stripped.
        const visibleText = streamed.suppressPseudoParse || protocol === "native"
            ? streamed.text.trim()
            : stripToolCalls(streamed.text);
        if (visibleText)
            lastVisible = visibleText;
        const nativeCalls: NativeToolCall[] = protocol === "native" && options.allowTools !== false ? (streamed.toolCalls ?? []) : [];
        if (nativeCalls.length > 0) {
            yield { type: "assistant_raw", text: streamed.text, toolCalls: nativeCalls, ...(streamed.reasoning ? { reasoning: streamed.reasoning } : {}) };
            if (visibleText)
                yield { type: "assistant_text", text: visibleText };
            history = [...history, { role: "assistant", content: streamed.text, toolCalls: nativeCalls }];
            const nativeIds = nativeCalls.map((native) => native.id || `tc_${++toolCallSeq}`);
            const executed = new Set<string>();
            for (let nativeIndex = 0; nativeIndex < nativeCalls.length; nativeIndex += 1) {
                const native = nativeCalls[nativeIndex];
                if (signal?.aborted) {
                    stopReason = "aborted";
                    break;
                }
                const id = nativeIds[nativeIndex];
                let call: ToolCall;
                let parseError = "";
                try {
                    const args = native.arguments ? JSON.parse(native.arguments) : {};
                    if (!args || typeof args !== "object" || Array.isArray(args))
                        throw new Error("arguments must be a JSON object");
                    call = { ...args, tool: native.name };
                }
                catch (err: any) {
                    parseError = `invalid arguments for ${native.name}: ${err?.message ?? String(err)}`;
                    protocolErrors += 1;
                    call = { tool: native.name };
                }
                const fingerprint = toolCallFingerprint(call, cwd);
                if (!isLoopExempt(call.tool)) {
                    const verdict = loop.check(fingerprint, isReadOnlyToolCall(call));
                    if (verdict.action === "warn") {
                        yield { type: "loop_detected", fingerprint, occurrences: verdict.occurrences, warned: false };
                        history = [...history, { role: "system", content: LOOP_WARNING }];
                    }
                    else if (verdict.action === "stop") {
                        stopReason = "loop_detected";
                        errorMessage = `Loop detected: the same tool call repeated ${verdict.occurrences} times. Stopped before executing it again.`;
                        yield { type: "error", kind: "loop_detected", message: errorMessage, text: lastVisible };
                        break;
                    }
                }
                yield { type: "tool_call", id, call, native: true };
                const result: any = parseError
                    ? { ok: false, output: parseError }
                    : await runAgentTool(call, cwd, { signal, turn: turn + 1, requestApproval: options.requestApproval });
                if (typeof result.output === "string")
                    result.output = boundToolMessage(result.output);
                trackSideEffects(activeFiles, result.sideEffects);
                if (result.egress)
                    yield { type: "egress_denied", ...result.egress };
                yield { type: "tool_result", id, call, ok: Boolean(result.ok), output: String(result.output ?? ""), ...toolResultMeta(result) };
                history = [...history, { role: "tool", toolCallId: id, content: String(result.output ?? "") }];
                executed.add(id);
            }
            // Aborted or loop-stopped mid-batch: every tool_call_id still needs
            // a matching tool message, or the next request is invalid.
            for (const id of nativeIds) {
                if (executed.has(id))
                    continue;
                history = [...history, {
                    role: "tool",
                    toolCallId: id,
                    content: "[not executed: the run stopped before this tool call could run]",
                }];
            }
            yield { type: "checkpoint", turn: turn + 1, cwd, providerId: provider.id, model, activeFiles: Array.from(activeFiles.values()) };
            if (stopReason === "complete")
                options.onNativeOk?.();
            if (stopReason !== "complete")
                break;
            continue;
        }
        // Two protocol parsers are mutually exclusive: a native turn never
        // rescans text for pseudo calls (the model was given schemas instead).
        const parsed = options.allowTools === false || streamed.suppressPseudoParse || protocol === "native"
            ? { calls: [] as ToolCall[], consumedEnd: 0, errors: [] as string[], errorCodes: [] as string[], detectedDialects: [] as string[] }
            : parseToolCalls(streamed.text);
        const calls: ToolCall[] = parsed.calls;
        yield { type: "assistant_raw", text: streamed.text, ...(streamed.reasoning ? { reasoning: streamed.reasoning } : {}) };
        if (calls.length === 0) {
            const foreignDialect = parsed.detectedDialects.length > 0 ||
                parsed.errorCodes.includes("UNSUPPORTED_DIALECT") ||
                parsed.errors.some((error) => /unsupported tool-call dialect/i.test(error));
            if (foreignDialect) {
                // Recognized but unexecutable markup: report once and stop.
                // Re-prompting here is what let one bad example burn every turn.
                protocolErrors += 1;
                const detail = parsed.detectedDialects.length > 0
                    ? `Detected tool-call dialects: ${parsed.detectedDialects.join(", ")}.`
                    : "Detected an unsupported tool-call dialect.";
                stopReason = "protocol_error";
                errorMessage = `${detail} No valid call could be parsed; stopping instead of re-emitting.`;
                yield { type: "checkpoint", turn: turn + 1, cwd, providerId: provider.id, model, activeFiles: Array.from(activeFiles.values()) };
                break;
            }
            if (parsed.errors.length > 0) {
                // Never let a broken <fastcode_tool> block end the turn silently:
                // inject one visible tool error so the model can re-emit. The
                // same fingerprint twice means it did not recover — stop.
                const reemitKey = parsed.errors.join("\n");
                if (protocolReemit.has(reemitKey)) {
                    protocolErrors += 1;
                    stopReason = "protocol_error";
                    errorMessage = "Tool-call markup was invalid again after one re-emit request; stopped instead of looping.";
                    yield { type: "checkpoint", turn: turn + 1, cwd, providerId: provider.id, model, activeFiles: Array.from(activeFiles.values()) };
                    break;
                }
                protocolReemit.add(reemitKey);
                protocolErrors += 1;
                const id = `tc_${++toolCallSeq}`;
                const call: ToolCall = { tool: "protocol_error" };
                const output = "Previous output contained invalid tool-call markup. " +
                    "Re-emit a complete <fastcode_tool>{\"tool\":...}</fastcode_tool> block.\n" +
                    parsed.errors.join("\n");
                yield { type: "tool_call", id, call };
                yield { type: "tool_result", id, call, ok: false, output, code: "INVALID_ARGS", hint: "Re-emit a complete tool call." };
                history = [...history, { role: "user", content: formatToolResults([{ call, ok: false, output }]) }];
                yield { type: "checkpoint", turn: turn + 1, cwd, providerId: provider.id, model, activeFiles: Array.from(activeFiles.values()) };
                continue;
            }
            lastVisible = visibleText || streamed.text;
            naturalFinish = true;
            stopReason = "complete";
            yield { type: "checkpoint", turn: turn + 1, cwd, providerId: provider.id, model, activeFiles: Array.from(activeFiles.values()) };
            break;
        }
        history = [...history, { role: "assistant", content: streamed.text }];
        if (visibleText)
            yield { type: "assistant_text", text: visibleText };
        const results: Array<{ call: ToolCall; ok: boolean; output: string; sideEffects?: SideEffects }> = [];
        for (const call of calls) {
            if (signal?.aborted) {
                stopReason = "aborted";
                break;
            }
            const fingerprint = toolCallFingerprint(call, cwd);
            if (!isLoopExempt(call.tool)) {
                const verdict = loop.check(fingerprint, isReadOnlyToolCall(call));
                if (verdict.action === "warn") {
                    yield { type: "loop_detected", fingerprint, occurrences: verdict.occurrences, warned: false };
                    history = [...history, { role: "system", content: LOOP_WARNING }];
                }
                else if (verdict.action === "stop") {
                    stopReason = "loop_detected";
                    errorMessage = `Loop detected: the same tool call repeated ${verdict.occurrences} times. Stopped before executing it again.`;
                    yield { type: "error", kind: "loop_detected", message: errorMessage, text: lastVisible };
                    break;
                }
            }
            const id = `tc_${++toolCallSeq}`;
            yield { type: "tool_call", id, call };
            const result: any = await runAgentTool(call, cwd, { signal, turn: turn + 1, requestApproval: options.requestApproval });
            if (typeof result.output === "string")
                result.output = boundToolMessage(result.output);
            results.push({ call, ok: Boolean(result.ok), output: String(result.output ?? ""), sideEffects: result.sideEffects });
            trackSideEffects(activeFiles, result.sideEffects);
            if (result.egress)
                yield { type: "egress_denied", ...result.egress };
            yield { type: "tool_result", id, call, ok: Boolean(result.ok), output: String(result.output ?? ""), ...toolResultMeta(result) };
        }
        if (results.length > 0)
            history = [...history, { role: "user", content: formatToolResults(results) }];
        yield { type: "checkpoint", turn: turn + 1, cwd, providerId: provider.id, model, activeFiles: Array.from(activeFiles.values()) };
        if (stopReason !== "complete")
            break;
    }
    if (stopReason === "stream_error") {
        const partial = lastVisible;
        if (partial)
            history = [...history, { role: "assistant", content: partial }];
        yield { type: "done", history, finalText: partial, stopReason };
        return;
    }
    if (stopReason === "complete" && !naturalFinish)
        stopReason = "max_turns";
    // Repeated broken markup/arguments must not look like a normal turn cap:
    // surface it as its own stop reason so scripts get a non-zero exit.
    if (stopReason === "max_turns" && protocolErrors > 0) {
        stopReason = "protocol_error";
        errorMessage = `Tool-call protocol failed ${protocolErrors} time(s); the run stopped before producing a valid tool call.`;
    }
    let finalText = "";
    if (stopReason === "aborted") {
        const partial = stripToolCalls(currentText).trim() || lastVisible;
        finalText = (partial ? partial + "\n\n" : "") + "[用户中断]";
        yield { type: "error", kind: "aborted", message: "Cancelled.", text: partial };
    }
    else if (stopReason === "protocol_error") {
        finalText = lastVisible || errorMessage;
        yield { type: "error", kind: "protocol_error", message: errorMessage, text: lastVisible || undefined };
    }
    else if (stopReason === "token_budget" || stopReason === "cost_budget" || stopReason === "loop_detected" || stopReason === "incomplete") {
        finalText = lastVisible || errorMessage;
    }
    else if (stopReason === "max_turns") {
        finalText = `Reached the maximum of ${maxTurns} agent tool turns. The work so far is kept in this session — type 继续 to keep going.`;
    }
    else {
        finalText = lastVisible;
    }
    if (finalText)
        history = [...history, { role: "assistant", content: finalText }];
    yield { type: "done", history, finalText, stopReason };
}

function positive(value: number | undefined, fallback: number): number {
    return typeof value === "number" && Number.isFinite(value) && value > 0 ? Math.floor(value) : fallback;
}

function optionalPositive(value: number | undefined): number | undefined {
    return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : undefined;
}

function toolResultMeta(result: ToolResult) {
    return {
        sideEffects: result.sideEffects,
        ...(result.code ? { code: result.code } : {}),
        ...(result.hint ? { hint: result.hint } : {}),
        ...(result.truncated !== undefined ? { truncated: result.truncated } : {}),
        ...(result.totalLines !== undefined ? { totalLines: result.totalLines } : {}),
        ...(result.returnedLines !== undefined ? { returnedLines: result.returnedLines } : {}),
        ...(result.totalBytes !== undefined ? { totalBytes: result.totalBytes } : {}),
        ...(result.returnedBytes !== undefined ? { returnedBytes: result.returnedBytes } : {}),
        ...(result.filesRead !== undefined ? { filesRead: result.filesRead } : {}),
        ...(result.filesSkipped !== undefined ? { filesSkipped: result.filesSkipped } : {}),
        ...(result.matches !== undefined ? { matches: result.matches } : {}),
    };
}

function trackSideEffects(activeFiles: Map<string, ActiveFile>, sideEffects: SideEffects | undefined): void {
    if (!sideEffects)
        return;
    for (const file of [...(sideEffects.touched ?? []), ...(sideEffects.created ?? [])]) {
        const meta = describeActiveFile(file);
        if (meta)
            activeFiles.set(file, meta);
    }
    for (const file of sideEffects.removed ?? [])
        activeFiles.delete(file);
}

function describeActiveFile(file: string): ActiveFile | undefined {
    try {
        const info = statSync(file);
        if (!info.isFile())
            return undefined;
        const sha1_8 = info.size > 8 * 1024 * 1024
            ? "large"
            : createHash("sha1").update(readFileSync(file)).digest("hex").slice(0, 8);
        return { path: file, sha1_8, mtime: info.mtime.toISOString() };
    }
    catch {
        return undefined;
    }
}
