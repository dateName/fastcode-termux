import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { createHash } from "node:crypto";
/**
 * FastCode App component — the heart of the TUI.
 *
 * Responsibilities:
 *   • Render banner, transcript, prompt, and status bar.
 *   • Drive the chat loop: send user messages, stream provider responses,
 *     update token/cost state, and persist config across runs.
 *   • Dispatch slash commands.
 *   • Cancel streaming on Esc and quit cleanly on /exit.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Box, Static, Text, useApp, useInput } from "ink";
import { agentSystemPrompt, stripToolCalls, } from "./agent/protocol.js";
import { compactionConfigFromEnv, removeSummaryFile } from "./agent/compaction.js";
import { rememberToolCapability, resolveToolProtocol } from "./agent/protocol-mode.js";
import { runAgent } from "./agent/runner.js";
import { decisionForOption, parseApprovalChoice, type ApprovalDecision, type ApprovalRequest } from "./agent/approval.js";
import { nativeApproval } from "./agent/approval-native.js";
import { toolSchemas } from "./agent/tool-schemas.js";
import { setShellPoolSize as applyShellPoolSize, shutdownShells, shutdownShellsAsync } from "./agent/shell-session.js";
import { Banner } from "./ui/Banner.js";
import { Spinner } from "./ui/Spinner.js";
import { StatusBar } from "./ui/StatusBar.js";
import { MessageBubble } from "./ui/Message.js";
import { Prompt } from "./ui/Prompt.js";
import { Picker } from "./ui/Picker.js";
import { pickerWindowStart } from "./ui/picker-window.js";
import { COMMANDS, findCommand, parseSlash } from "./commands/index.js";
import { maskLoginEcho, saveScopedKey } from "./commands/login.js";
import { isValidModelId } from "./commands/model.js";
import { getProvider, getProviderOrThrow, probeProviderDetailed, PROVIDERS } from "./providers/index.js";
import { loadConfig, saveConfig, resolveApiKey, resolveProviderKey, getLegacy, } from "./config/store.js";
import { getTheme } from "./config/themes.js";
import { createStartupTranscript } from "./lib/startup.js";
import { shouldUseLiveStreamingUi, shouldUseStableTerminalUi } from "./lib/uiMode.js";
import { buildPluginsPrompt } from "./plugins/manager.js";
import { buildSkillsPrompt } from "./skills/manager.js";
import { createSessionLog, latestUnclosedSession, loggingEnabled, openSessionLog, readSession, staleSummaryRefs } from "./session/log.js";
import { resumeSession } from "./session/projection.js";
import { applyPlan, applyRevert } from "./session/actions.js";
import { discoverInstructions, formatInstructionPrompt } from "./session/instructions.js";
import { formatPlan, latestPlan } from "./session/plan.js";
import { isTrusted, trustProject } from "./config/trust.js";
import { TrustGate } from "./ui/TrustGate.js";
import type { CommandCompaction } from "./types.js";
function positiveInt(value, fallback) {
    return typeof value === "number" && Number.isFinite(value) && value > 0 ? Math.floor(value) : fallback;
}
function streamingTail(text, maxLines = 6) {
    const lines = String(text ?? "").split(/\r?\n/);
    if (lines.length <= maxLines)
        return String(text ?? "");
    return "…\n" + lines.slice(-maxLines).join("\n");
}
function collapseToolOutput(output) {
    const text = String(output ?? "");
    const lines = text.split(/\r?\n/);
    const first = (lines.find((line) => line.trim()) ?? "").trim();
    const clipped = first.length > 160 ? first.slice(0, 157) + "..." : first;
    const rest = Math.max(0, lines.length - 1);
    return `${clipped}${clipped ? "\n" : ""}[${rest} more lines, ${text.length} chars]`;
}
function optionalBudget(name) {
    const value = Number(process.env[name]);
    return Number.isFinite(value) && value > 0 ? value : undefined;
}
function uniqueModelList(models) {
    const seen = new Set();
    const result = [];
    for (const model of models) {
        if (!model?.id || seen.has(model.id))
            continue;
        seen.add(model.id);
        result.push(model);
    }
    return result;
}
function unclosedNotice(session) {
    const where = session.cwd || "(unknown directory)";
    const files = session.activeFiles?.length ?? 0;
    return `Last session did not close normally (${where}, ~${session.turns} turns, ${files} file${files === 1 ? "" : "s"} changed).\n` +
        `Resume it with \`fastcode resume ${session.id}\`, or list sessions with \`fastcode sessions\`.`;
}
function streamErrorMessage(message, provider, model) {
    if (/\b(401|403)\b/.test(message) || /invalid api key|unauthorized|authentication/i.test(message)) {
        return `Authentication failed for ${provider.label} · ${model}. The key may be wrong or not allowed for this model.\n` +
            `Check with \`/whoami\`, or re-save: \`/login ${provider.id} ${model} <key>\`.`;
    }
    if (/\b(402|429)\b/.test(message) || /quota|rate limit|billing|insufficient (?:balance|quota|credit|funds)|exceeded .*(?:quota|balance|limit)/i.test(message)) {
        return `Request blocked: ${provider.label} reports no remaining quota / rate limit for ${model}.\n` +
            `Top up the account or switch model/provider. (${message.slice(0, 200)})`;
    }
    return `Error: ${message}`;
}
export const App = ({ initialPrompt, resume, ui = "tty" }) => {
    const { exit } = useApp();
    const startupRef = useRef(null);
    if (!startupRef.current) {
        const config = loadConfig();
        const resumed = resume ? resumeSession(resume) : undefined;
        if (resumed) {
            const provider = resumed.meta.providerId ? getProvider(resumed.meta.providerId) : undefined;
            if (provider) {
                config.providerId = provider.id;
                if (resumed.meta.model)
                    config.model = resumed.meta.model;
            }
        }
        const restored = resumed?.messages ?? [];
        const transcript = restored.length > 0
            ? restored.map((message, index) => ({
                id: index + 1,
                role: message.role,
                content: message.role === "assistant" ? stripToolCalls(message.content) : message.content,
                markdown: message.role !== "user",
            }))
            : createStartupTranscript(config);
        if (resumed) {
            const push = (text) => transcript.push({ id: transcript.length + 1, role: "system", content: text, markdown: true });
            if (resumed.meta.providerId && !getProvider(resumed.meta.providerId))
                push(`The session used provider ${resumed.meta.providerId}, which is not available in this build.`);
            push(`Resumed session: ${config.providerId}::${config.model}${resumed.rebuilt ? " (projection rebuilt)" : ""}.`);
            for (const warning of resumed.warnings)
                push(warning);
        }
        else if (!resume && loggingEnabled()) {
            const unclosed = latestUnclosedSession();
            if (unclosed) {
                transcript.push({
                    id: transcript.length + 1,
                    role: "system",
                    content: unclosedNotice(unclosed),
                    markdown: true,
                });
            }
        }
        startupRef.current = {
            config,
            transcript,
            history: restored.map((message) => ({ role: message.role, content: message.content })),
        };
    }
    const startup = startupRef.current;
    const sessionRef = useRef(null as any);
    if (!sessionRef.current) {
        sessionRef.current = resume
            ? openSessionLog(resume, {
                providerId: startup.config.providerId,
                model: startup.config.model,
                cwd: process.cwd(),
            })
            : createSessionLog({
                providerId: startup.config.providerId,
                model: startup.config.model,
                cwd: process.cwd(),
            });
    }
    const [, setTrustEpoch] = useState(0);
    const trusted = isTrusted(process.cwd());
    const [config, setConfig] = useState(startup.config);
    const [history, setHistory] = useState(startup.history ?? []);
    const [transcript, setTranscript] = useState(startup.transcript);
    const [streamingId, setStreamingId] = useState(null);
    const [streamingText, setStreamingText] = useState("");
    const [streamPhase, setStreamPhase] = useState("thinking");
    const [input, setInput] = useState("");
    const [pendingLogin, setPendingLogin] = useState(null);
    const [picker, setPicker] = useState(null);
    const [pickerIndex, setPickerIndex] = useState(0);
    const modelSetupIdRef = useRef(0);
    const openModelSetupPickerRef = useRef(null);
    const plainApprovalRef = useRef<null | {
        request: ApprovalRequest;
        submit(text: string): void;
        cancel(): void;
    }>(null);
    const [approvalFeedbackPrompt, setApprovalFeedbackPrompt] = useState<string | null>(null);
    const approvalFeedbackRef = useRef<null | {
        submit(text: string): void;
        cancel(): void;
    }>(null);
    const [busy, setBusy] = useState(false);
    const [expanded, setExpanded] = useState(false);
    const steerQueueRef = useRef([]);
    const [totalIn, setTotalIn] = useState(0);
    const [totalOut, setTotalOut] = useState(0);
    const [totalCost, setTotalCost] = useState(0);
    const [agentActivity, setAgentActivity] = useState(null);
    const idRef = useRef(startup.transcript.length);
    const abortRef = useRef(null);
    const sawDeltaRef = useRef(false);
    const lastStreamFlushRef = useRef(0);
    const ctrlCRef = useRef(0);
    const exitConfirmRef = useRef(0);
    const busyRef = useRef(false);
    const initialPromptSubmittedRef = useRef(false);
    const quittingRef = useRef(false);
    const quitCleanly = useCallback(async () => {
        if (quittingRef.current)
            return;
        quittingRef.current = true;
        if (abortRef.current) {
            abortRef.current.abort();
            abortRef.current = null;
        }
        // Give the aborted run a chance to append its final facts before the
        // session save point is closed.
        const idleDeadline = Date.now() + 1000;
        while (busyRef.current && Date.now() < idleDeadline)
            await new Promise((resolve) => setTimeout(resolve, 20));
        try {
            await shutdownShellsAsync(400);
        }
        catch {
            shutdownShells();
        }
        try {
            sessionRef.current?.close?.({ reason: "exit" });
        }
        catch {
            // Session close is best effort during exit.
        }
        exit();
    }, [exit]);
    useEffect(() => {
        applyShellPoolSize(config.shellPoolSize);
    }, [config.shellPoolSize]);
    const theme = getTheme(config.theme);
    const stableUi = useMemo(() => shouldUseStableTerminalUi(), []);
    const liveStreamingUi = useMemo(() => shouldUseLiveStreamingUi(), []);
    // The banner picks a font that fits the terminal width (see ui/Banner.ts)
    // and renders nothing when even the smallest font is too wide.
    const showBanner = transcript.length <= startup.transcript.length && !busy;
    const promptPlaceholder = approvalFeedbackPrompt
        ? `${approvalFeedbackPrompt} · Esc to cancel`
        : pendingLogin
        ? pendingLogin.step === "loading-models"
            ? "Loading available models…"
            : pendingLogin.step === "model-manual"
            ? "Model id (e.g. deepseek-flash) · Esc to cancel"
            : pendingLogin.hasExistingKey
                ? "API key (masked), or Enter to keep existing key · Esc to cancel"
                : pendingLogin.provider && getLegacy(pendingLogin.provider)
                    ? "API key (masked), or type 'keep' · Esc to cancel"
                    : "Paste API key (masked) · Esc to cancel"
        : undefined;
    const promptMask = pendingLogin?.step === "key" ? "*" : undefined;
    // Persist config whenever it changes.
    useEffect(() => {
        saveConfig(config);
    }, [config]);
    const chooseItem = useCallback((request, index) => {
        const item = request?.items?.[index];
        setPicker(null);
        if (item)
            request.onSelect(item.value, item);
    }, []);
    // Esc cancels streaming. Double Ctrl+C quits.
    useInput((inputChar, key) => {
        if (picker) {
            if (key.escape || (key.ctrl && inputChar === "c")) {
                const onCancel = picker.onCancel;
                setPicker(null);
                onCancel?.();
                return;
            }
            if (picker.items.length === 0)
                return;
            if (key.upArrow) {
                setPickerIndex((i) => Math.max(0, i - 1));
                return;
            }
            if (key.downArrow) {
                setPickerIndex((i) => Math.min(picker.items.length - 1, i + 1));
                return;
            }
            if (key.return) {
                chooseItem(picker, pickerIndex);
                return;
            }
            if (/^[1-9]$/.test(inputChar)) {
                const start = pickerWindowStart(picker.items.length, pickerIndex);
                chooseItem(picker, start + Number(inputChar) - 1);
                return;
            }
            return;
        }
        if (key.escape || (key.ctrl && inputChar === "c" && (approvalFeedbackRef.current || plainApprovalRef.current || pendingLogin))) {
            if (approvalFeedbackRef.current) {
                approvalFeedbackRef.current.cancel();
                return;
            }
            if (plainApprovalRef.current) {
                plainApprovalRef.current.cancel();
                return;
            }
            if (pendingLogin) {
                modelSetupIdRef.current += 1;
                setPendingLogin(null);
                setInput("");
                pushSystem("Model configuration cancelled. Existing settings were not changed.");
                return;
            }
            if (abortRef.current) {
                abortRef.current.abort();
                abortRef.current = null;
            }
            return;
        }
        if (key.ctrl && inputChar === "c") {
            ctrlCRef.current += 1;
            if (busy && ctrlCRef.current === 1) {
                if (abortRef.current) {
                    abortRef.current.abort();
                    abortRef.current = null;
                }
                pushSystem("Cancelled current run; partial output kept. Press Ctrl+C again to quit, or type 继续 to continue.");
                setTimeout(() => {
                    ctrlCRef.current = 0;
                }, 1500);
                return;
            }
            if (ctrlCRef.current >= 2) {
                void quitCleanly();
            }
            else {
                pushSystem("Press Ctrl+C again to quit.");
                setTimeout(() => {
                    ctrlCRef.current = 0;
                }, 1500);
            }
        }
    });
    const pushSystem = useCallback((text) => {
        idRef.current += 1;
        sessionRef.current.append({ type: "notice", content: text });
        setTranscript((prev) => [
            ...prev,
            { id: idRef.current, role: "system", content: text, markdown: true },
        ]);
    }, []);
    const pushUser = useCallback((text, recordFact = true) => {
        idRef.current += 1;
        sessionRef.current.append(recordFact
            ? { type: "user", content: text }
            : { type: "notice", content: text });
        setTranscript((prev) => [
            ...prev,
            { id: idRef.current, role: "user", content: text, markdown: false },
        ]);
    }, []);
    const finishModelSetup = useCallback((setup, providerId, modelId, keyReceipt = undefined) => {
        if (setup.id !== modelSetupIdRef.current)
            return;
        const provider = getProvider(providerId);
        if (!provider) {
            setPendingLogin(null);
            setInput("");
            pushSystem("Provider is no longer available. Configuration was not changed.");
            return;
        }
        setConfig((current) => ({ ...current, providerId: provider.id, model: modelId }));
        setPendingLogin(null);
        setInput("");
        modelSetupIdRef.current += 1;
        pushSystem(keyReceipt
            ? `${keyReceipt}\nActive model: ${provider.id} · ${modelId}.`
            : `Provider/model set to ${provider.id} · ${modelId}. ${provider.authEnv.length === 0 ? "No API key is required." : ""}`);
    }, [pushSystem]);
    const continueModelSetup = useCallback((setup, providerId, modelId) => {
        if (setup.id !== modelSetupIdRef.current)
            return;
        const provider = getProvider(providerId);
        if (!provider) {
            setPendingLogin(null);
            pushSystem("Unknown provider. Configuration was not changed.");
            return;
        }
        if (provider.authEnv.length === 0) {
            finishModelSetup(setup, provider.id, modelId);
            return;
        }
        const existing = resolveApiKey(provider.id, modelId, provider.authEnv);
        setPendingLogin({
            ...setup,
            step: "key",
            provider: provider.id,
            model: modelId,
            hasExistingKey: existing.status === "ok",
        });
        setPicker(null);
        setInput("");
        pushSystem(`Selected ${provider.label} · ${modelId}. Enter the API key for this provider. ` +
            "The key is provider-wide and will be reused for its models." +
            (existing.status === "ok" ? " Press Enter on an empty input to keep the existing key." : ""));
    }, [finishModelSetup, pushSystem]);
    const openModelSetupPicker = useCallback(async (setup, step, providerId = undefined) => {
        if (setup.id !== modelSetupIdRef.current)
            return;
        if (step === "provider") {
            setPendingLogin({ ...setup, step: "provider", provider: undefined, model: undefined });
            const currentProvider = setup.provider ?? config.providerId;
            setPickerIndex(Math.max(0, PROVIDERS.findIndex((provider) => provider.id === currentProvider)));
            setPicker({
                title: "Configure provider · choose a provider",
                current: currentProvider,
                items: PROVIDERS.map((provider) => ({
                    value: provider.id,
                    label: `${provider.id.padEnd(12)} ${provider.label}`,
                    hint: provider.authEnv.length === 0 ? "no API key required" : provider.defaultModel,
                })),
                onSelect: (id) => {
                    const selected = getProvider(id);
                    if (!selected)
                        return;
                    const nextSetup = {
                        ...setup,
                        provider: selected.id,
                        model: selected.id === config.providerId ? config.model : selected.defaultModel,
                    };
                    void openModelSetupPickerRef.current?.(nextSetup, "model", selected.id);
                },
                onCancel: () => {
                    if (setup.id !== modelSetupIdRef.current)
                        return;
                    modelSetupIdRef.current += 1;
                    setPendingLogin(null);
                    setInput("");
                    pushSystem("Model configuration cancelled. Existing settings were not changed.");
                },
            });
            return;
        }

        const provider = getProvider(providerId);
        if (!provider) {
            setPendingLogin(null);
            pushSystem("Unknown provider. Configuration was not changed.");
            return;
        }
        setPendingLogin({ ...setup, step: "loading-models", provider: provider.id });
        setInput("");
        setPickerIndex(0);
        setPicker({
            title: `Loading models · ${provider.label}`,
            current: undefined,
            items: [],
            onSelect: () => { },
            onCancel: () => {
                if (setup.id !== modelSetupIdRef.current)
                    return;
                modelSetupIdRef.current += 1;
                setPendingLogin(null);
                setInput("");
                pushSystem("Model configuration cancelled. Existing settings were not changed.");
            },
        });
        const { key } = resolveProviderKey(provider.id, provider.authEnv);
        let models = [];
        let online = false;
        let probeReason = "";
        try {
            models = uniqueModelList(await provider.listModels(key));
            const probe = await probeProviderDetailed(provider, key);
            online = probe.ok;
            probeReason = probe.reason;
        }
        catch (err: any) {
            online = false;
            probeReason = err?.message ?? "probe failed";
        }
        if (setup.id !== modelSetupIdRef.current)
            return;
        if (provider.defaultModel && !models.some((model) => model.id === provider.defaultModel))
            models.unshift({ id: provider.defaultModel, label: "provider default" });
        const manualModelValue = "__fastcode_manual_model_id__";
        const items = [
            ...models.slice(0, 49).map((model) => ({
                value: model.id,
                label: model.id,
                hint: model.label && model.label !== model.id ? model.label : undefined,
            })),
            { value: manualModelValue, label: "Enter model ID manually…" },
        ];
        const currentModel = setup.model ?? provider.defaultModel;
        const currentIndex = items.findIndex((item) => item.value === currentModel);
        setPendingLogin({ ...setup, step: "model", provider: provider.id, model: currentModel });
        setPickerIndex(currentIndex >= 0 ? currentIndex : 0);
        pushSystem(`Models for ${provider.label}: ${models.length}${online ? "" : ` (${probeReason || "offline"}; showing built-in/cached models)`}.`);
        setPicker({
            title: `Configure model · ${provider.label}${online ? "" : ` · offline: ${probeReason || "unreachable"}`}`,
            current: currentModel,
            items,
            onSelect: (id) => {
                if (setup.id !== modelSetupIdRef.current)
                    return;
                if (id === manualModelValue) {
                    setPendingLogin({ ...setup, step: "model-manual", provider: provider.id });
                    setInput("");
                    pushSystem("Enter a model ID (letters, numbers, . _ : / + -; up to 200 characters).");
                    return;
                }
                continueModelSetup(setup, provider.id, id);
            },
            onCancel: () => {
                if (setup.id === modelSetupIdRef.current)
                    void openModelSetupPickerRef.current?.(setup, "provider");
            },
        });
    }, [config.model, config.providerId, continueModelSetup, pushSystem]);
    openModelSetupPickerRef.current = openModelSetupPicker;
    const startModelSetup = useCallback(({ provider, model, flow = "login" }) => {
        const setup = {
            id: ++modelSetupIdRef.current,
            flow,
            originalProvider: config.providerId,
            originalModel: config.model,
            provider,
            model,
        };
        setPendingLogin(setup);
        setInput("");
        if (flow === "model" && provider) {
            void openModelSetupPicker(setup, "model", provider);
        }
        else if (provider && model) {
            continueModelSetup(setup, provider, model);
        }
        else if (provider) {
            void openModelSetupPicker(setup, "model", provider);
        }
        else {
            void openModelSetupPicker(setup, "provider");
        }
    }, [config.model, config.providerId, continueModelSetup, openModelSetupPicker]);
    const requestApproval = useCallback(async (request: ApprovalRequest): Promise<ApprovalDecision> => {
        const defaultDecision = (): ApprovalDecision => {
            const option = request.options[request.defaultIndex ?? 0];
            if (!option || option.kind === "allow")
                return { kind: "deny", reason: "approval timeout/cancel (fail closed)" };
            return decisionForOption(option);
        };
        if (ui === "native" && process.platform !== "win32") {
            const native = await nativeApproval(request, abortRef.current?.signal);
            if (native)
                return native;
        }
        const preview = request.preview?.kind === "diff" && request.preview.text
            ? `\n\n${request.preview.text.slice(0, 4000)}`
            : "";
        pushSystem(`[approval] Tier ${request.tier ?? 2} · ${request.tool}\n${request.prompt ?? "Approval required"}${preview}`);
        if (ui === "json") {
            return { kind: "deny", reason: "JSON approval mode requires the headless protocol channel (not wired in this build)" };
        }
        const approvalSignal = abortRef.current?.signal;
        if (ui === "plain") {
            return await new Promise((resolve) => {
                let settled = false;
                let timer;
                const onAbort = () => finish({ kind: "deny", reason: "run cancelled" });
                const finish = (decision: ApprovalDecision) => {
                    if (settled)
                        return;
                    settled = true;
                    if (timer)
                        clearTimeout(timer);
                    approvalSignal?.removeEventListener("abort", onAbort);
                    plainApprovalRef.current = null;
                    resolve(decision);
                };
                approvalSignal?.addEventListener("abort", onAbort, { once: true });
                const lines = request.options.map((option, index) => `${index + 1}. ${option.label}`);
                pushSystem(`Choose an option:\n${lines.join("\n")}\nEnter a number (1-${request.options.length}); Esc cancels.`);
                plainApprovalRef.current = {
                    request,
                    submit: (text) => {
                        const option = parseApprovalChoice(request, text);
                        if (!option) {
                            pushSystem(`Invalid approval choice. Enter 1-${request.options.length}.`);
                            return;
                        }
                        if (option.kind === "feedback") {
                            const prompt = option.prompt || "Why should this be denied?";
                            pushSystem(`${prompt}\nType your reason and press Enter; Esc cancels.`);
                            plainApprovalRef.current = {
                                request,
                                submit: (feedbackText) => {
                                    const feedback = feedbackText.trim();
                                    if (!feedback) {
                                        pushSystem("Feedback cannot be empty. Type a reason, or Esc to cancel.");
                                        return;
                                    }
                                    finish({ kind: "feedback", text: feedback });
                                },
                                cancel: () => finish({ kind: "deny", reason: "cancelled during feedback" }),
                            };
                            return;
                        }
                        finish(decisionForOption(option));
                    },
                    cancel: () => finish({ kind: "deny", reason: "cancelled" }),
                };
                timer = setTimeout(() => {
                    pushSystem("Approval timed out; applying the most conservative option.");
                    finish(defaultDecision());
                }, Math.max(1000, request.timeoutMs ?? 60_000));
                timer.unref?.();
            });
        }
        return await new Promise((resolve) => {
            let settled = false;
            let timer;
            const onAbort = () => finish({ kind: "deny", reason: "run cancelled" });
            const finish = (decision: ApprovalDecision) => {
                if (settled)
                    return;
                settled = true;
                if (timer)
                    clearTimeout(timer);
                approvalSignal?.removeEventListener("abort", onAbort);
                if (approvalFeedbackRef.current) {
                    approvalFeedbackRef.current = null;
                    setApprovalFeedbackPrompt(null);
                }
                setPicker(null);
                resolve(decision);
            };
            approvalSignal?.addEventListener("abort", onAbort, { once: true });
            const items = request.options.map((option, index) => ({
                value: option.id ?? String(index),
                label: option.label,
            }));
            const defaultIndex = Math.max(0, Math.min(request.defaultIndex ?? 0, items.length - 1));
            setPickerIndex(defaultIndex);
            setPicker({
                title: `Approval · Tier ${request.tier ?? 2}`,
                items,
                current: items[defaultIndex]?.value,
                onSelect: (value) => {
                    const index = items.findIndex((item) => item.value === value);
                    const option = request.options[index];
                    if (!option) {
                        finish({ kind: "deny", reason: "unknown approval option" });
                        return;
                    }
                    if (option.kind === "feedback") {
                        const prompt = option.prompt || "Why should this be denied?";
                        setPicker(null);
                        setInput("");
                        setApprovalFeedbackPrompt(prompt);
                        pushSystem(`${prompt}\nType your reason and press Enter; Esc cancels.`);
                        approvalFeedbackRef.current = {
                            submit: (text) => {
                                const feedback = text.trim();
                                if (!feedback) {
                                    pushSystem("Feedback cannot be empty. Type a reason, or Esc to cancel.");
                                    return;
                                }
                                finish({ kind: "feedback", text: feedback });
                            },
                            cancel: () => finish({ kind: "deny", reason: "cancelled during feedback" }),
                        };
                        return;
                    }
                    finish(decisionForOption(option));
                },
                onCancel: () => finish({ kind: "deny", reason: "cancelled" }),
            });
            timer = setTimeout(() => {
                pushSystem("Approval timed out; applying the most conservative option.");
                finish(defaultDecision());
            }, Math.max(1000, request.timeoutMs ?? 60_000));
            timer.unref?.();
        });
    }, [pushSystem, ui]);

    // Approval decisions are events; trusted.json is authorization state. Keep
    // them separate: record the decision + scope + request id + a stable key
    // digest so resume can explain what was approved without treating the
    // fact as a grant.
    const recordApprovalFact = useCallback((request: ApprovalRequest, decision: ApprovalDecision) => {
        if (!sessionRef.current)
            return;
        const approvalKey = createHash("sha256")
            .update(JSON.stringify({ tool: request.tool, args: request.args }))
            .digest("hex")
            .slice(0, 8);
        sessionRef.current.append({
            type: "approval",
            requestId: request.id,
            tool: request.tool,
            decision: decision.kind,
            approvalKey,
            ...(request.tier !== undefined ? { tier: request.tier } : {}),
            ...(decision.kind === "allow" ? { scope: decision.scope } : {}),
            ...(decision.kind === "deny" && decision.reason ? { reason: decision.reason } : {}),
            ...(decision.kind === "feedback" ? { feedback: true } : {}),
        });
    }, []);

    const actions = useMemo(() => ({
        setProvider: (id) => setConfig((c) => ({ ...c, providerId: id })),
        setModel: (id) => setConfig((c) => ({ ...c, model: id })),
        setReasoningEffort: (effort) => setConfig((c) => ({ ...c, reasoningEffort: effort })),
        setTheme: (id) => setConfig((c) => ({ ...c, theme: id })),
        setAgentMode: (enabled) => setConfig((c) => ({ ...c, agentMode: enabled })),
        setSystemPrompt: (p) => setConfig((c) => ({ ...c, systemPrompt: p })),
        setSkillsRegistry: (url) => setConfig((c) => ({ ...c, skillsRegistry: url })),
        setShellPoolSize: (size) => {
            const applied = applyShellPoolSize(size);
            setConfig((c) => ({ ...c, shellPoolSize: applied }));
        },
        enableSkill: (name) => setConfig((c) => ({
            ...c,
            enabledSkills: Array.from(new Set([...(c.enabledSkills ?? []), name])),
        })),
        disableSkill: (name) => setConfig((c) => ({
            ...c,
            enabledSkills: (c.enabledSkills ?? []).filter((n) => n !== name),
        })),
        enablePlugin: (name) => setConfig((c) => ({
            ...c,
            enabledPlugins: Array.from(new Set([...(c.enabledPlugins ?? []), name])),
        })),
        disablePlugin: (name) => setConfig((c) => ({
            ...c,
            enabledPlugins: (c.enabledPlugins ?? []).filter((n) => n !== name),
        })),
        clearHistory: () => {
            setHistory([]);
            setTranscript([]);
        },
        replaceHistory: (messages) => setHistory(messages),
        cancelRun: () => {
            if (abortRef.current) {
                abortRef.current.abort();
                abortRef.current = null;
            }
        },
        steer: (text) => {
            steerQueueRef.current.push(text);
        },
        setExpanded: (value) => setExpanded(value),
        setInput: (value) => setInput(value),
        pushSystemMessage: pushSystem,
        startLogin: (options) => startModelSetup(options),
    }), [pushSystem, startModelSetup]);
    const appendCompactionFact = useCallback((info: CommandCompaction) => {
        const file = sessionRef.current?.file;
        sessionRef.current.append({ type: "compacted", ...info });
        if (typeof file === "string") {
            for (const ref of staleSummaryRefs(file))
                removeSummaryFile(ref);
        }
    }, []);
    const runSlash = useCallback(async (raw) => {
        const parsed = parseSlash(raw);
        if (!parsed)
            return false;
        const cmd = findCommand(parsed.name);
        if (!cmd) {
            pushSystem(`Unknown command "/${parsed.name}". Try /help.`);
            return true;
        }
        if (cmd.name === "exit" && busy) {
            const now = Date.now();
            if (now - exitConfirmRef.current > 5000) {
                exitConfirmRef.current = now;
                pushSystem("A run is active. /exit will stop it, keep the partial output, and save the session. " +
                    "Type /exit again within 5s to confirm, or /cancel to stop first.");
                return true;
            }
            exitConfirmRef.current = 0;
        }
        if (busy && !["cancel", "steer", "jobs", "kill", "attach", "expand", "context", "threads", "exit"].includes(cmd.name)) {
            pushSystem(`/${cmd.name} is unavailable while a run is active. Try /cancel or /steer.`);
            return true;
        }
        // Echo the slash invocation for transcript clarity, but never echo a
        // secret: the login key is masked, while provider/model stay readable.
        const echo = parsed.name === "login" ? maskLoginEcho(parsed.args) : raw;
        pushUser(echo, false);
        try {
            const res = await cmd.run({
                args: parsed.args,
                raw: parsed.raw,
                state: {
                    providerId: config.providerId,
                    model: config.model,
                    theme: config.theme,
                    agentMode: config.agentMode,
                    history,
                    systemPrompt: config.systemPrompt,
                    totalCostUsd: totalCost,
                    totalInputTokens: totalIn,
                    totalOutputTokens: totalOut,
                    enabledSkills: config.enabledSkills,
                    enabledPlugins: config.enabledPlugins,
                    skillsRegistry: config.skillsRegistry,
                    reasoningEffort: config.reasoningEffort,
                    expanded,
                    busy,
                    draft: input,
                    plan: sessionRef.current?.file ? latestPlan(readSession(sessionRef.current.file)) : undefined,
                },
                actions,
            });
            if (res?.message)
                pushSystem(res.message);
            if (res?.picker) {
                const index = Math.max(0, res.picker.items.findIndex((item) => item.value === res.picker.current));
                setPickerIndex(index);
                setPicker(res.picker);
                setInput("");
            }
            if (res?.compacted)
                appendCompactionFact(res.compacted);
            if (res?.cleared)
                sessionRef.current.append({ type: "cleared" });
            if (typeof res?.revert === "number") {
                const action = sessionRef.current ? applyRevert(sessionRef.current, res.revert) : undefined;
                if (!action) {
                    pushSystem(`Cannot revert to user message ${res.revert}; no active session log.`);
                }
                else if (action.ok) {
                    setHistory(action.messages);
                    idRef.current += 1;
                    setTranscript([{
                        id: idRef.current,
                        role: "system",
                        content: action.notice,
                        markdown: true,
                    }]);
                }
                else {
                    pushSystem((action as { message?: string }).message ?? "Revert failed.");
                }
            }
            if (res?.plan) {
                const action = sessionRef.current ? applyPlan(sessionRef.current, res.plan) : undefined;
                if (!action) {
                    pushSystem("Could not persist the plan; no active session log.");
                }
                else if (action.ok) {
                    setHistory(action.messages);
                    idRef.current += 1;
                    setTranscript((prev) => [
                        ...prev,
                        { id: idRef.current, role: "system", content: formatPlan(action.plan), markdown: true },
                    ]);
                }
                else {
                    pushSystem((action as { message?: string }).message ?? "Plan update failed.");
                }
            }
            if (res?.quit)
                void quitCleanly();
        }
        catch (err) {
            pushSystem(parsed.name === "login"
                ? "Login failed. The credential was not included in this error message."
                : `Command failed: ${err.message}`);
        }
        return true;
    }, [
        actions,
        appendCompactionFact,
        config.agentMode,
        config.enabledPlugins,
        config.enabledSkills,
        config.model,
        config.providerId,
        config.skillsRegistry,
        config.systemPrompt,
        config.theme,
        busy,
        expanded,
        quitCleanly,
        history,
        pushSystem,
        pushUser,
        totalCost,
        totalIn,
        totalOut,
    ]);
    const handleSubmit = useCallback(async (raw) => {
        const text = raw.trim();
        if (!text)
            return;
        if (approvalFeedbackRef.current) {
            approvalFeedbackRef.current.submit(text);
            setInput("");
            return;
        }
        if (plainApprovalRef.current) {
            plainApprovalRef.current.submit(text);
            setInput("");
            return;
        }
        if (busy) {
            if (text.startsWith("/")) {
                await runSlash(text);
                return;
            }
            pushSystem("A run is active. Use /cancel to stop, /steer <text> to guide it, or wait.");
            return;
        }
        setInput("");
        if (text.startsWith("/")) {
            await runSlash(text);
            return;
        }
        pushUser(text);
        const provider = getProviderOrThrow(config.providerId);
        let apiKey;
        if (provider.authEnv.length > 0) {
            const lookup = resolveApiKey(provider.id, config.model, provider.authEnv);
            if (lookup.status === "unbound") {
                pushSystem(`Cannot send: your stored ${provider.label} key isn't bound to a model, so it won't be used.\n` +
                    `Re-bind it with \`/login ${provider.id} ${config.model} <key>\` (or \`/logout ${provider.id}\` to discard it).`);
                return;
            }
            if (lookup.status === "missing") {
                pushSystem(`Cannot send: no API key for ${provider.label}.\n` +
                    `Run \`/login ${provider.id} ${config.model} <key>\` (one key covers every ${provider.id} model), or set ${provider.authEnv[0]}.`);
                return;
            }
            apiKey = lookup.key;
        }
        idRef.current += 1;
        const bubbleId = idRef.current;
        setStreamingId(bubbleId);
        setStreamingText("");
        setStreamPhase("thinking");
        steerQueueRef.current = [];
        lastStreamFlushRef.current = 0;
        const ctrl = new AbortController();
        abortRef.current = ctrl;
        busyRef.current = true;
        setBusy(true);
        let receivedDone = false;
        try {
            const maxTurns = config.agentMode ? positiveInt(config.maxAgentTurns, 24) : 1;
            const skillsBlock = buildSkillsPrompt(config.enabledSkills);
            const pluginsBlock = buildPluginsPrompt(config.enabledPlugins);
            const protocol = config.agentMode ? resolveToolProtocol(config, config.providerId, config.model) : "legacy";
            const agentBlock = config.agentMode ? agentSystemPrompt(protocol) : "";
            const instructionsBlock = formatInstructionPrompt(discoverInstructions(process.cwd()).entries);
            const fullSystem = [config.systemPrompt, skillsBlock, pluginsBlock, instructionsBlock, agentBlock]
                .filter((part) => part.trim())
                .join("\n\n");
            let compactionNotified = false;
            let lastRawFact = "";
            sawDeltaRef.current = false;
            for await (const ev of runAgent({
                provider,
                apiKey,
                model: config.model,
                messages: history,
                prompt: text,
                system: fullSystem,
                maxTurns,
                allowTools: config.agentMode,
                tokenBudget: optionalBudget("FASTCODE_TOKEN_BUDGET"),
                costBudgetUsd: optionalBudget("FASTCODE_COST_BUDGET_USD"),
                signal: ctrl.signal,
                cwd: process.cwd(),
                idleTimeoutMs: config.requestIdleTimeoutMs,
                compaction: compactionConfigFromEnv(),
                reasoningEffort: config.reasoningEffort,
                protocol,
                tools: protocol === "native" ? toolSchemas() : undefined,
                onProtocolFallback: (message) => {
                    rememberToolCapability(config.providerId, config.model, "pseudo");
                    pushSystem(message);
                },
                onNativeOk: () => {
                    if (protocol === "native")
                        rememberToolCapability(config.providerId, config.model, "native");
                },
                takeSteering: () => {
                    const queued = steerQueueRef.current;
                    steerQueueRef.current = [];
                    return queued;
                },
                requestApproval: async (request) => {
                    const decision = await requestApproval(request);
                    recordApprovalFact(request, decision);
                    return decision;
                },
                onDelta: (delta, full) => {
                    if (!sawDeltaRef.current) {
                        sawDeltaRef.current = true;
                        setStreamPhase("streaming");
                    }
                    if (!liveStreamingUi)
                        return;
                    const now = Date.now();
                    if (now - lastStreamFlushRef.current < 60)
                        return;
                    lastStreamFlushRef.current = now;
                    setStreamingText(stripToolCalls(full));
                },
            })) {
                switch (ev.type) {
                    case "compaction":
                        appendCompactionFact({
                            summaryRef: ev.summaryFile,
                            source: ev.source,
                            beforeTokens: ev.beforeTokens,
                            afterTokens: ev.afterTokens,
                            droppedMessages: ev.droppedMessages,
                            keepMessages: ev.keptMessages,
                            reason: ev.reason === "heap" ? "heap" : "threshold",
                        });
                        if (!compactionNotified) {
                            compactionNotified = true;
                            pushSystem(`[context compacted] ${ev.beforeTokens} → ${ev.afterTokens} tokens (${ev.reason}); recent turns kept.` +
                                (ev.summaryFile ? `\nSummary: ${ev.summaryFile}` : ""));
                        }
                        break;
                    case "assistant_raw":
                        lastRawFact = ev.text;
                        sessionRef.current.append({
                            type: "assistant_raw",
                            content: ev.text,
                            toolCalls: ev.toolCalls,
                            ...(ev.reasoning ? { reasoning: ev.reasoning } : {}),
                        });
                        break;
                    case "assistant_text":
                        pushSystem(ev.text);
                        break;
                    case "tool_call":
                        sessionRef.current.append({ type: "tool_call", id: ev.id, tool: ev.call.tool, args: ev.call, native: Boolean(ev.native) });
                        setStreamPhase("tool");
                        setAgentActivity(`Coding: ${ev.call.tool}`);
                        pushSystem(`Running tool: \`${ev.call.tool}\`\n\n\`\`\`json\n${JSON.stringify(ev.call, null, 2)}\n\`\`\``);
                        break;
                    case "tool_result": {
                        sessionRef.current.append({
                            type: "tool_result",
                            id: ev.id,
                            tool: ev.call.tool,
                            ok: ev.ok,
                            output: ev.output,
                            sideEffects: ev.sideEffects,
                            ...(ev.code ? { code: ev.code } : {}),
                            ...(ev.hint ? { hint: ev.hint } : {}),
                            ...(ev.truncated !== undefined ? { truncated: ev.truncated } : {}),
                            ...(ev.totalLines !== undefined ? { totalLines: ev.totalLines } : {}),
                            ...(ev.returnedLines !== undefined ? { returnedLines: ev.returnedLines } : {}),
                            ...(ev.totalBytes !== undefined ? { totalBytes: ev.totalBytes } : {}),
                            ...(ev.returnedBytes !== undefined ? { returnedBytes: ev.returnedBytes } : {}),
                            ...(ev.filesRead !== undefined ? { filesRead: ev.filesRead } : {}),
                            ...(ev.filesSkipped !== undefined ? { filesSkipped: ev.filesSkipped } : {}),
                            ...(ev.matches !== undefined ? { matches: ev.matches } : {}),
                            ...(ev.oldText !== undefined ? { oldText: ev.oldText } : {}),
                            ...(ev.newText !== undefined ? { newText: ev.newText } : {}),
                            ...(ev.changedStartLine !== undefined ? { changedStartLine: ev.changedStartLine } : {}),
                            ...(ev.oldLineCount !== undefined ? { oldLineCount: ev.oldLineCount } : {}),
                            ...(ev.newLineCount !== undefined ? { newLineCount: ev.newLineCount } : {}),
                            ...(ev.diffTruncated !== undefined ? { diffTruncated: ev.diffTruncated } : {}),
                            ...(ev.diffs ? { diffs: ev.diffs } : {}),
                            ...(ev.atomic === false ? { atomic: false } : {}),
                            ...(ev.check ? { check: ev.check } : {}),
                        });
                        const collapsed = stableUi && !expanded;
                        const body = collapsed ? collapseToolOutput(ev.output) : ev.output;
                        const hint = collapsed ? "\n\n_(output collapsed; /expand to show full output)_" : "";
                        const clipDiff = (text) => {
                            const value = String(text ?? "");
                            return value.length > 2_000 ? value.slice(0, 2_000) + "\n[... diff text truncated ...]" : value;
                        };
                        const diffDetail = expanded && ev.diffs?.length
                            ? ev.diffs.map((diff) => `### ${diff.path}\n- old:\n\`\`\`\n${clipDiff(diff.oldText)}\n\`\`\`\n+ new:\n\`\`\`\n${clipDiff(diff.newText)}\n\`\`\``).join("\n\n")
                            : "";
                        const diffInfo = ev.diffs?.length
                            ? `\n\n_diff: ${ev.diffs.length} file(s)${diffDetail ? `\n\n${diffDetail}` : ""}_`
                            : ev.oldText !== undefined && ev.newText !== undefined
                                ? `\n\n_diff: line ${ev.changedStartLine ?? "?"} · ${ev.oldLineCount ?? "?"} → ${ev.newLineCount ?? "?"} line(s)${ev.diffTruncated ? " (truncated)" : ""}_`
                                : "";
                        const atomicInfo = ev.atomic === false ? "\n\n_[atomic] rename unavailable; fallback copy used (best-effort)_" : "";
                        pushSystem(`Tool ${ev.ok ? "completed" : "failed"}: \`${ev.call.tool}\`\n\n\`\`\`\n${body}\n\`\`\`${hint}${diffInfo}${atomicInfo}`);
                        break;
                    }
                    case "usage":
                        if (ev.usage.inputTokens)
                            setTotalIn((n) => n + (ev.usage.inputTokens ?? 0));
                        if (ev.usage.outputTokens)
                            setTotalOut((n) => n + (ev.usage.outputTokens ?? 0));
                        if (ev.usage.costUsd)
                            setTotalCost((n) => n + (ev.usage.costUsd ?? 0));
                        break;
                    case "loop_detected":
                        pushSystem(`Loop detected: \`${ev.fingerprint.split(":")[0]}\` repeated ${ev.occurrences} times. Asking the model to change approach.`);
                        break;
                    case "egress_denied": {
                        idRef.current += 1;
                        sessionRef.current.append({
                            type: "egress_denied",
                            outlet: ev.outlet,
                            target: ev.target,
                            rule: ev.rule,
                            mode: ev.mode,
                            wouldBlock: ev.wouldBlock,
                            code: ev.code,
                            reason: ev.reason,
                        });
                        const target = ev.target ? ` target=${JSON.stringify(ev.target)}` : "";
                        setTranscript((prev) => [
                            ...prev,
                            { id: idRef.current, role: "system", content: `[egress] ${ev.mode} rule=${ev.rule}${target} would_block=${ev.wouldBlock}\n${ev.reason}`, markdown: true },
                        ]);
                        break;
                    }
                    case "notice":
                        pushSystem(ev.text);
                        break;
                    case "checkpoint":
                        sessionRef.current.append({
                            type: "checkpoint",
                            turn: ev.turn,
                            cwd: ev.cwd,
                            providerId: ev.providerId,
                            model: ev.model,
                            activeFiles: ev.activeFiles,
                            lastFactSeq: sessionRef.current.count(),
                        });
                        break;
                    case "error":
                        if (ev.kind === "aborted")
                            pushSystem("Cancelled current run; partial output kept. Type 继续 to continue.");
                        else if (ev.kind === "stream_error")
                            pushSystem(streamErrorMessage(ev.message, provider, config.model));
                        else
                            pushSystem(ev.message);
                        break;
                    case "done":
                        receivedDone = true;
                        setHistory(ev.history);
                        if (ev.finalText) {
                            idRef.current += 1;
                            const finalId = idRef.current;
                            if (ev.finalText !== lastRawFact)
                                sessionRef.current.append({ type: "assistant_raw", content: ev.finalText });
                            setTranscript((prev) => [
                                ...prev,
                                { id: finalId, role: "assistant", content: ev.finalText, markdown: true },
                            ]);
                        }
                        break;
                }
            }
        }
        catch (err) {
            if (!receivedDone)
                setHistory([...history, { role: "user", content: text }]);
            pushSystem(`Error: ${String(err?.message ?? err)}`);
        }
        finally {
            setStreamingId(null);
            setStreamingText("");
            setAgentActivity(null);
            setStreamPhase("thinking");
            busyRef.current = false;
            setBusy(false);
            abortRef.current = null;
        }
    }, [
        appendCompactionFact,
        busy,
        config.agentMode,
        config.enabledSkills,
        config.enabledPlugins,
        config.model,
        config.providerId,
        config.systemPrompt,
        history,
        pushSystem,
        pushUser,
        recordApprovalFact,
        requestApproval,
        runSlash,
    ]);
    // Guided `/login`: provider → model → key. Text prompts only; the key step
    // is masked. `keep` re-binds an existing unbound (legacy) key to a model.
    const handleWizardSubmit = useCallback(async (raw) => {
        const value = raw.trim();
        setInput("");
        if (!pendingLogin)
            return;
        if (pendingLogin.step === "model-manual") {
            if (!isValidModelId(value)) {
                pushSystem("Invalid model ID. Use 1-200 letters, numbers, or . _ : / + -; configuration was not changed.");
                return;
            }
            continueModelSetup(pendingLogin, pendingLogin.provider, value);
            return;
        }
        if (pendingLogin.step !== "key")
            return;
        const provider = getProvider(pendingLogin.provider);
        if (!provider) {
            setPendingLogin(null);
            pushSystem("Provider is no longer available. Configuration was not changed.");
            return;
        }
        if (!value) {
            if (pendingLogin.hasExistingKey) {
                finishModelSetup(pendingLogin, provider.id, pendingLogin.model);
            }
            else {
                pushSystem("An API key is required for this provider. Configuration was not changed.");
            }
            return;
        }
        let key = value;
        if (value.toLowerCase() === "keep") {
            const legacy = getLegacy(provider.id);
            if (!legacy) {
                pushSystem(`No stored ${provider.label} key to reuse. Paste the API key; configuration was not changed.`);
                return;
            }
            key = legacy;
        }
        try {
            const receipt = saveScopedKey(provider.id, provider.label, pendingLogin.model, key);
            finishModelSetup(pendingLogin, provider.id, pendingLogin.model, receipt);
        }
        catch {
            pushSystem("Could not save the API key. Credential details were omitted; model settings were not changed.");
        }
    }, [continueModelSetup, finishModelSetup, pendingLogin, pushSystem]);
    useEffect(() => {
        if (!initialPrompt || initialPromptSubmittedRef.current)
            return;
        initialPromptSubmittedRef.current = true;
        const t = setTimeout(() => void handleSubmit(initialPrompt), 50);
        return () => clearTimeout(t);
    }, [handleSubmit, initialPrompt]);
    useEffect(() => () => {
        shutdownShells();
        if (sessionRef.current)
            sessionRef.current.close();
    }, []);
    if (config.agentMode && !trusted) {
        const decide = (allow) => {
            if (allow) {
                trustProject(process.cwd());
            }
            else {
                setConfig((c) => ({ ...c, agentMode: false }));
                pushSystem("Trust declined: agent tools are off for this session (chat only).");
            }
            setTrustEpoch((n) => n + 1);
        };
        return _jsx(TrustGate, { theme: theme, cwd: process.cwd(), onDecision: decide });
    }
    return (_jsxs(Box, { flexDirection: "column", paddingX: 1, children: [showBanner ? _jsx(Banner, { theme: theme, stable: stableUi }) : null, _jsx(Static, { items: transcript, children: (entry) => (_jsx(Box, { marginTop: 1, children: _jsx(MessageBubble, { theme: theme, role: entry.role, content: entry.content, markdown: entry.markdown }) }, entry.id)) }), streamingId !== null && liveStreamingUi ? (_jsx(Box, { marginTop: 1, flexDirection: "column", children: _jsx(MessageBubble, { theme: theme, role: "assistant", content: streamingTail(streamingText, 6), markdown: false, streaming: true }) })) : null, _jsxs(Box, { marginTop: 1, flexDirection: "column", children: [busy ? (_jsx(Box, { marginBottom: 1, children: _jsx(Spinner, { theme: theme, label: agentActivity ?? (streamPhase === "streaming" ? "Streaming" : streamPhase === "tool" ? "Waiting for tool" : "Thinking"), stable: stableUi }) })) : null, picker ? _jsx(Picker, { theme: theme, title: picker.title, items: picker.items, index: pickerIndex, current: picker.current }) : _jsx(Prompt, { theme: theme, value: input, onChange: setInput, onSubmit: pendingLogin ? handleWizardSubmit : handleSubmit, disabled: false, placeholder: promptPlaceholder, mask: promptMask }), _jsx(StatusBar, { theme: theme, providerId: config.providerId, model: config.model, inputTokens: totalIn, outputTokens: totalOut, costUsd: totalCost, enabledSkillCount: config.enabledSkills.length + config.enabledPlugins.length, reasoningEffort: config.reasoningEffort }), _jsxs(Text, { color: theme.muted, children: [COMMANDS.length, " commands \u00B7 ", config.enabledSkills.length, " skill(s) active"] })] })] }));
};
