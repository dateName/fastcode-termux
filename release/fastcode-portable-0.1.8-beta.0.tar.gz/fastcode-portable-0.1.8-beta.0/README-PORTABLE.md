# FastCode 免安装便携包 v0.1.8-beta.0

已内置依赖，解压后无需 npm install，只要有 Node.js 18.17 以上即可。

    chmod +x fastcode
    ./fastcode doctor
    ./fastcode

Windows:  fastcode.cmd doctor
直接调用:  node package/bin/fastcode.mjs doctor

详情见项目 docs/DEPLOYMENT.md 与 docs/CONFIGURATION.md。
