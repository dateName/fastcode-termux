/**
 * CLI argument parsing.
 *
 * \`fastcode\` launches the TUI. The non-interactive helpers let you configure
 * and script FastCode straight from a Termux shell, without starting Ink:
 * provider/model selection, config paths, skills, doctor and update.
 */
import meow from "meow";
import { readPackageMeta } from "./lib/pkg.js";
import { installSkill, listInstalledSkills, uninstallSkill, searchRegistry, resolveRegistry } from "./skills/manager.js";
import { loadConfig, saveConfig, resolveProviderKey } from "./config/store.js";
import { getPaths } from "./config/paths.js";
import { buildConfigExport } from "./config/export.js";
import { writeFileSync } from "node:fs";
import { PROVIDERS, getProvider } from "./providers/index.js";
import { collectDiagnostics, formatDiagnostics } from "./lib/diagnostics.js";
import { probeConnectivity } from "./lib/http.js";
import { copyFileSync, existsSync, readFileSync, statSync } from "node:fs";
import { latestSessionFile, listSessions, projectionPath, readSession, resolveResumeFile, resolveSessionFile } from "./session/log.js";
import { readProjection, sessionMetaFromFile } from "./session/projection.js";
import { forgetToolApproval, listToolApprovals, listTrusted, trustProject, untrustProject } from "./config/trust.js";
import { isValidModelId } from "./commands/model.js";
import { toolCatalogHash } from "./agent/registry.js";
const NL = String.fromCharCode(10);
const HELP = [
    "",
    "  FastCode — multi-LLM TUI coding assistant",
    "",
    "  Usage",
    "    $ fastcode                       Launch the TUI",
    "    $ fastcode \"explain this repo\"   Launch the TUI with an initial prompt",
    "    $ fastcode help                  Show this help",
    "",
    "  Model & provider (no TUI needed)",
    "    $ fastcode provider              List providers",
    "    $ fastcode provider <id> [model] Set the default provider (model required if none is known)",
    "    $ fastcode model                 List models for the current provider",
    "    $ fastcode model <id>            Set the default model",
    "    $ fastcode config                Print config file and data paths",
    "    $ fastcode config path           Print just the config file path",
    "    $ fastcode sessions              List saved sessions (JSONL)",
    "    $ fastcode sessions show <id>    Print a saved session",
    "    $ fastcode resume [id|latest]    Resume a saved session in the TUI",
    "",
    "  Trust (first-run safety)",
    "    $ fastcode trust [dir]           Trust a folder (enables agent tools)",
    "    $ fastcode untrust [dir]         Revoke trust for a folder",
    "    $ fastcode trusted               List trusted folders and remembered approvals",
    "    $ fastcode trust --forget <key>  Revoke one remembered approval",
    "",
    "  Skills & maintenance",
    "    $ fastcode skills list           Print installed skills",
    "    $ fastcode skills install <id>   Install a skill from the registry",
    "    $ fastcode skills uninstall <id> Remove an installed skill",
    "    $ fastcode skills search <q>     Search the registry",
    "    $ fastcode doctor                Environment diagnostics (Termux/mobile)",
    "    $ fastcode doctor --net          Also probe registry connectivity",
    "    $ fastcode doctor --backup-check Check config/auth/trust/model-meta backups",
    "    $ fastcode update                Check for a newer release",
    "",
    "  Options",
    "    --long-run, --full-access   Long-run mode: turns=9999, anchor 30000 chars;\n                                 does NOT disable egress/trust/sandbox/approval",
    "    --cost-cap <USD>            Process-local cost cap (default: unlimited)",
    "    --version, -v   Show version",
    "    --help, -h      Show this help",
    "",
    "  Data directory (default ~/.fastcode, override with FASTCODE_HOME):",
    "    config.json       provider, model, theme, agent mode, enabled skills/plugins, egress",
    "    auth.json         API keys only, separate file (chmod 0600)",
    "    trusted.json      trusted folders + remembered tool approvals",
    "    model-meta.json   optional model context / charsPerToken overrides",
    "    skills/           installed SKILL.md folders",
    "    plugins/          always-active plugin packs",
    "    sessions/         JSONL history + <id>.projection.json",
    "    cache/ + logs/    caches and debug logs (safe to delete)",
    "",
    "  API keys may also come from ENV (DEEPSEEK_API_KEY, ANTHROPIC_API_KEY,",
    "  OPENAI_API_KEY, GEMINI_API_KEY, OPENROUTER_API_KEY, GROQ_API_KEY,",
    "  MISTRAL_API_KEY, XAI_API_KEY, MOONSHOT_API_KEY, ZHIPUAI_API_KEY,",
    "  DASHSCOPE_API_KEY) or from /login inside the TUI.",
    "",
    "  Approval UI:  --ui tty|native|plain|json   (default tty)",
    "",
].join(NL);
export async function parseCli(): Promise<any> {
    // meow's autoHelp covers `--help` but not `-h`; handle both (and `help`)
    // here so every documented spelling prints the same formatted help.
    const argv = process.argv.slice(2);
    if (argv.includes("-h") || argv.includes("--help") || argv[0] === "help") {
        console.log(HELP);
        return { done: true };
    }
    if (argv.includes("-v") || argv.includes("--version")) {
        console.log(readPackageMeta().version);
        return { done: true };
    }
    const cli = meow(HELP, {
        importMeta: import.meta,
        flags: {
            version: { type: "boolean", shortFlag: "v" },
            ui: { type: "string", default: "tty" },
            forget: { type: "string" },
            net: { type: "boolean", default: false },
            backupCheck: { type: "boolean", default: false },
            fullAccess: { type: "boolean", default: false },
            longRun: { type: "boolean", default: false },
            costCap: { type: "string" },
        },
        autoHelp: true,
        autoVersion: true,
    });
    const uiMode = String(cli.flags.ui ?? "tty").toLowerCase();
    const longRun = Boolean(cli.flags.fullAccess || cli.flags.longRun);
    if (longRun)
        process.env.FASTCODE_LONG_RUN = "1";
    if (typeof cli.flags.costCap === "string") {
        const cap = Number(cli.flags.costCap);
        if (!Number.isFinite(cap) || cap <= 0) {
            console.error("Invalid --cost-cap: " + cli.flags.costCap);
            process.exit(1);
        }
        process.env.FASTCODE_COST_BUDGET_USD = String(cap);
    }
    if (!["tty", "native", "plain", "json"].includes(uiMode)) {
        console.error("Unknown --ui mode: " + uiMode + " (use tty, native, plain, or json)");
        process.exit(1);
    }
    // First positional dictates the sub-command. Anything else is a prompt.
    const [first, ...rest] = cli.input;
    if (first === "provider") {
        const cfg = loadConfig();
        const paths = getPaths();
        if (rest.length === 0) {
            const lines = ["Providers (current: " + cfg.providerId + ")"];
            for (const p of PROVIDERS) {
                const marker = p.id === cfg.providerId ? "●" : " ";
                const auth = p.authEnv.length === 0 ? "(no key needed)" : "[" + p.authEnv.join(", ") + "]";
                lines.push("  " + marker + " " + p.id.padEnd(12) + " " + p.label + "  " + auth);
            }
            lines.push("");
            lines.push("Switch:  fastcode provider <id>");
            lines.push("Or edit: " + paths.config);
            console.log(lines.join(NL));
            return { done: true };
        }
        const next = getProvider(rest[0]);
        if (!next) {
            console.error("Unknown provider: " + rest[0] + ". Run: fastcode provider");
            process.exit(1);
        }
        const modelArg = rest.slice(1).join(" ").trim();
        if (!next.defaultModel && !modelArg) {
            console.error("Provider " + next.id + " has no verified default model. Use: fastcode provider " + next.id + " <model>");
            process.exit(1);
        }
        if (modelArg && !isValidModelId(modelArg)) {
            console.error("Invalid model ID. Use 1-200 letters, numbers, or . _ : / + -; configuration was not changed.");
            process.exit(1);
        }
        const nextModel = modelArg || next.defaultModel;
        saveConfig({ ...cfg, providerId: next.id, model: nextModel });
        console.log("Provider: " + next.id + " (" + next.label + ")");
        console.log("Model:    " + nextModel);
        console.log("Saved to " + paths.config);
        console.log("API keys stay in " + paths.auth + " (untouched)");
        return { done: true };
    }
    if (first === "model") {
        const cfg = loadConfig();
        const paths = getPaths();
        if (rest.length === 0) {
            const provider = getProvider(cfg.providerId);
            console.log("Provider: " + cfg.providerId + "   Model: " + (cfg.model || "(not set)"));
            if (provider) {
                let models = [];
                try {
                    const { key } = resolveProviderKey(provider.id, provider.authEnv);
                    models = await provider.listModels(key);
                }
                catch {
                    models = [];
                }
                if (models.length > 0) {
                    console.log("");
                    console.log("Known models for " + provider.label + " (use /model in the TUI for the live list):");
                    for (const m of models.slice(0, 40)) {
                        const marker = m.id === cfg.model ? "●" : " ";
                        console.log("  " + marker + " " + m.id + (m.label ? "  — " + m.label : ""));
                    }
                }
            }
            console.log("");
            console.log("Switch:  fastcode model <id>");
            console.log("Or edit: " + paths.config);
            return { done: true };
        }
        const id = rest.join(" ").trim();
        if (!isValidModelId(id)) {
            console.error("Invalid model ID. Use 1-200 letters, numbers, or . _ : / + -; configuration was not changed.");
            process.exit(1);
        }
        saveConfig({ ...cfg, model: id });
        console.log("Model: " + id + "   (provider " + cfg.providerId + ")");
        console.log("Saved to " + paths.config);
        return { done: true };
    }
    if (first === "config") {
        const paths = getPaths();
        if (rest[0] === "path") {
            console.log(paths.config);
            return { done: true };
        }
        if (rest[0] === "export") {
            const outIndex = rest.indexOf("--out");
            const out = outIndex >= 0 ? rest[outIndex + 1] : undefined;
            const data = buildConfigExport(paths, { withKeys: rest.includes("--with-keys") });
            const text = JSON.stringify(data, null, 2);
            if (out) {
                writeFileSync(out, text + "\n", { encoding: "utf8", mode: 0o600 });
                console.log("Exported config to " + out);
            }
            else {
                console.log(text);
            }
            if (rest.includes("--with-keys"))
                console.error("[fastcode] warning: export contains API keys; protect the file.");
            return { done: true };
        }
        if (rest[0] === "import") {
            const file = rest[1];
            if (!file || !existsSync(file)) {
                console.error("Usage: fastcode config import <file>");
                process.exit(1);
            }
            const data = JSON.parse(readFileSync(file, "utf8"));
            const targets = [
                ["config", paths.config],
                ["auth", paths.auth],
                ["trusted", paths.trust],
                ["modelMeta", paths.root + "/model-meta.json"],
            ];
            const stamp = Date.now();
            for (const [key, target] of targets) {
                if (!(key in data) || data[key] === undefined)
                    continue;
                if (key === "auth" && JSON.stringify(data.auth).includes("[REDACTED]")) {
                    console.error("[fastcode] auth export is redacted; keys were not imported. Re-export with --with-keys first.");
                    continue;
                }
                if (existsSync(target))
                    copyFileSync(target, target + ".import.bak." + stamp);
                writeFileSync(target, JSON.stringify(data[key], null, 2) + "\n", { encoding: "utf8", mode: 0o600 });
            }
            const currentCatalog = toolCatalogHash();
            const staleApprovals = data?.trusted?.tools && typeof data.trusted.tools === "object"
                ? Object.values(data.trusted.tools).filter((entry: any) => entry?.catalogHash && entry.catalogHash !== currentCatalog).length
                : 0;
            console.log("Imported config from " + file);
            console.log("  imported: " + targets.filter(([key]) => key in data && data[key] !== undefined).map(([key]) => key).join(", "));
            console.log("  backups:  " + targets.filter(([, target]) => existsSync(target)).length + " target(s), suffix .import.bak");
            console.error("[fastcode] remembered approvals may be invalid if the tool catalog changed; re-approve affected tools.");
            if (staleApprovals > 0)
                console.error("           " + staleApprovals + " remembered approval(s) use an older catalogHash and will require re-approval.");
            return { done: true };
        }
        const cfg = loadConfig();
        console.log("Config file: " + paths.config);
        console.log("Keys file:   " + paths.auth + "   (separate file, chmod 0600)");
        console.log("");
        console.log(JSON.stringify(cfg, null, 2));
        return { done: true };
    }
    if (first === "sessions") {
        const all = listSessions();
        if (all.length === 0) {
            console.log("No sessions yet. They are appended to " + getPaths().sessions);
            return { done: true };
        }
        if (rest[0] === "show") {
            const idOrFile = rest[1] ?? all[0].id;
            if (rest[1] && !existsSync(resolveSessionFile(rest[1]))) {
                console.error("No such session: " + rest[1]);
                process.exit(1);
            }
            const entries = readSession(idOrFile);
            for (const entry of entries) {
                if (entry.type === "message")
                    console.log("[" + entry.role + "] " + entry.content);
                else if (entry.type === "user" || entry.type === "assistant_raw")
                    console.log("[" + entry.type + "] " + String(entry.content ?? "").slice(0, 300));
                else
                    console.log("[" + entry.type + "]");
            }
            const file = resolveSessionFile(idOrFile);
            const projection = readProjection(file);
            console.log("");
            if (projection) {
                console.log("[projection] " + projectionPath(file));
                console.log("  messages: " + projection.messages.length + " · activeFiles: " + projection.activeFiles.length + " · lastFactSeq: " + projection.lastFactSeq);
            }
            else {
                console.log("[projection] (none)");
            }
            return { done: true };
        }
        console.log("Sessions (newest first):");
        for (const entry of all.slice(0, 20)) {
            console.log("  " + entry.id + "   " + (entry.bytes / 1024).toFixed(1) + "KB   " + entry.messages + " msgs   " + entry.modified);
        }
        console.log("");
        console.log("Resume:  fastcode resume [id|latest]");
        console.log("Show:    fastcode sessions show <id>");
        return { done: true };
    }
    if (first === "resume") {
        const target = rest[0];
        const file = !target || target === "latest" ? latestSessionFile() : resolveResumeFile(target);
        if (!file) {
            console.error("Resume expects a session id or a .jsonl file inside the sessions directory.");
            process.exit(1);
        }
        if (!existsSync(file)) {
            console.error("No saved session to resume. Start one with: fastcode");
            process.exit(1);
        }
        const meta = sessionMetaFromFile(file);
        if (meta.cwd) {
            if (existsSync(meta.cwd)) {
                process.chdir(meta.cwd);
                console.log("Working directory: " + meta.cwd);
            }
            else {
                console.log("Session directory no longer exists: " + meta.cwd + " (staying in " + process.cwd() + ")");
            }
        }
        if (meta.providerId)
            console.log("Session model: " + meta.providerId + "::" + meta.model);
        console.log("Resuming " + file);
        return { done: false, resume: file };
    }
    if (first === "trust" || first === "untrust" || first === "trusted") {
        if (first === "trusted") {
            const all = listTrusted();
            if (all.length === 0)
                console.log("No trusted folders yet. Run: fastcode trust");
            for (const entry of all)
                console.log("  " + entry.path + "   (" + entry.addedAt + ")");
            const approvals = listToolApprovals();
            if (approvals.length > 0) {
                console.log("");
                console.log("Remembered tool approvals:");
                for (const entry of approvals)
                    console.log("  " + entry.key + "   catalog=" + entry.catalogHash);
            }
            return { done: true };
        }
        if (first === "trust" && typeof cli.flags.forget === "string") {
            const key = String(cli.flags.forget).trim();
            if (!key) {
                console.error("Usage: fastcode trust --forget <key>");
                process.exit(1);
            }
            const forgotten = forgetToolApproval(key);
            console.log(forgotten ? "Forgot approval: " + key : "No such approval: " + key);
            if (!forgotten)
                process.exitCode = 1;
            return { done: true };
        }
        const dir = rest[0] ?? process.cwd();
        if (first === "trust") {
            console.log("Trusted: " + trustProject(dir));
        }
        else {
            console.log(untrustProject(dir) ? "Removed from the trusted list: " + dir : "Not in the trusted list: " + dir);
        }
        return { done: true };
    }
    if (first === "skills") {
        const sub = rest[0] ?? "list";
        const args = rest.slice(1);
        if (sub === "list" || sub === "ls") {
            const installed = listInstalledSkills();
            if (installed.length === 0) {
                console.log("No skills installed. Try: fastcode skills install <id>");
            }
            else {
                const widest = Math.max(...installed.map((s) => s.name.length));
                console.log("Installed skills (" + installed.length + "):");
                for (const s of installed)
                    console.log("  " + s.name.padEnd(widest) + "  " + s.source + "  " + s.path);
            }
            return { done: true };
        }
        if (sub === "install" || sub === "add") {
            if (args.length === 0) {
                console.error("Usage: fastcode skills install <id|owner/repo|url>");
                process.exit(1);
            }
            const cfg = loadConfig();
            const force = args.includes("--force");
            const spec = args.filter((a) => a !== "--force").join(" ");
            const skill = await installSkill(spec, { registry: cfg.skillsRegistry, force });
            console.log("Installed " + skill.name + " -> " + skill.path);
            return { done: true };
        }
        if (sub === "uninstall" || sub === "remove" || sub === "rm") {
            if (args.length === 0) {
                console.error("Usage: fastcode skills uninstall <id>");
                process.exit(1);
            }
            const ok = uninstallSkill(args[0]);
            console.log(ok ? "Removed " + args[0] + "." : "No skill named " + args[0] + ".");
            return { done: true };
        }
        if (sub === "search") {
            if (args.length === 0) {
                console.error("Usage: fastcode skills search <query>");
                process.exit(1);
            }
            const cfg = loadConfig();
            const registry = resolveRegistry(process.env["FASTCODE_SKILLS_REGISTRY"], cfg.skillsRegistry);
            if (!registry) {
                console.error("No skills registry configured. Set FASTCODE_SKILLS_REGISTRY or config.skillsRegistry.");
                process.exit(1);
            }
            const hits = await searchRegistry(args.join(" "), registry);
            if (hits.length === 0) {
                console.log("No matches.");
            }
            else {
                const shown = hits.slice(0, 20);
                const widest = Math.max(...shown.map((h) => h.slug.length));
                console.log("Matches (" + hits.length + ", showing " + shown.length + "):");
                for (const h of shown)
                    console.log("  " + h.slug.padEnd(widest) + "  " + (h.description ?? ""));
            }
            return { done: true };
        }
        console.error("Unknown skills sub-command: " + sub);
        process.exit(1);
    }
    if (first === "doctor") {
        console.log(formatDiagnostics(collectDiagnostics()));
        if (cli.flags.backupCheck === true) {
            const paths = getPaths();
            const entries = [["config", paths.config], ["auth", paths.auth], ["trusted", paths.trust], ["model-meta", paths.root + "/model-meta.json"]];
            for (const [label, file] of entries) {
                const present = existsSync(file);
                const mode = present && process.platform !== "win32" ? (statSync(file).mode & 0o777).toString(8).padStart(4, "0") : "n/a";
                console.log("  " + label.padEnd(12) + (present ? "present" : "missing") + "  mode " + mode + "  " + file);
                if (!present && label === "auth")
                    console.log("    fix: run /login (or set the provider ENV key) to create auth.json");
                if (present && label === "auth" && process.platform !== "win32" && mode !== "0600")
                    console.log("    fix: chmod 600 " + file);
            }
            console.log("  backups     run `fastcode config export --out <file>` before manual edits");
            return { done: true };
        }
        if (cli.flags.net === true) {
            const url = "https://registry.npmjs.org/";
            const reachable = await probeConnectivity(url);
            console.log(`  network       ${reachable ? "reachable" : "unreachable"} (${url})`);
        }
        return { done: true };
    }
    if (first === "update") {
        console.log(await updateReport());
        return { done: true };
    }
    // No sub-command → treat all positionals as the initial prompt.
    const prompt = cli.input.length > 0 ? cli.input.join(" ") : undefined;
    return prompt ? { prompt, done: false, ui: uiMode, longRun } : { done: false, ui: uiMode, longRun };
}
function compareVersions(a, b) {
    const pa = a.split(".").map((n) => parseInt(n, 10) || 0);
    const pb = b.split(".").map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
        const d = (pa[i] ?? 0) - (pb[i] ?? 0);
        if (d !== 0)
            return d > 0 ? 1 : -1;
    }
    return 0;
}
async function updateReport() {
    const meta = readPackageMeta();
    const lines = ["FastCode " + meta.version, ""];
    const registry = process.env["FASTCODE_UPDATE_REGISTRY"] ??
        "https://registry.npmjs.org/" + encodeURIComponent(meta.name) + "/latest";
    try {
        const res = await fetch(registry, { headers: { accept: "application/json" } });
        if (!res.ok)
            throw new Error(res.status + " " + res.statusText);
        const payload: any = await res.json();
        const latest = payload.version;
        const cmp = compareVersions(latest, meta.version);
        lines.push("Published latest: " + latest);
        lines.push(cmp > 0
            ? "Update available: " + meta.version + " -> " + latest
            : cmp < 0
                ? "This build (" + meta.version + ") is newer than the published " + latest + "."
                : "You are up to date.");
    }
    catch (err) {
        lines.push("Could not reach the registry: " + err.message);
    }
    lines.push("");
    lines.push("Update with one of:");
    lines.push("  npm install -g " + meta.name + "@latest");
    lines.push("  # or from a checkout:  git pull && npm install -g .");
    return lines.join(NL);
}
