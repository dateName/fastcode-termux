import { installSkill, uninstallSkill, listInstalledSkills, searchRegistry, getSkill, rebaselineSkills, resolveRegistry, } from "../skills/manager.js";
export const skillsCommand = {
    name: "skills",
    description: "Manage Agent Skills (download from skills.sh and toggle).",
    async run({ args, state, actions }) {
        const sub = (args[0] ?? "list").toLowerCase();
        const rest = args.slice(1);
        if (sub === "list" || sub === "ls") {
            const installed = listInstalledSkills();
            if (installed.length === 0) {
                return {
                    message: "No skills installed. Try `/skills search <query>` or `/skills install <name>`.",
                };
            }
            const lines = ["Installed skills:"];
            for (const s of installed) {
                const enabled = state.enabledSkills.includes(s.name) ? "● " : "  ";
                lines.push(`${enabled}${s.name}  — ${truncate(s.description, 80)}`);
                lines.push(`    source: ${s.source}`);
                if (s.integrity !== "ok")
                    lines.push(`    integrity: ${s.integrity === "drift" ? "DRIFT (disabled; run /skills verify " + s.name + " --confirm)" : "unverified (run /skills verify " + s.name + " --confirm)"}`);
            }
            lines.push("");
            lines.push("Toggle with `/skills enable <name>` or `/skills disable <name>`.");
            return { message: lines.join("\n") };
        }
        if (sub === "search") {
            const registry = resolveRegistry(process.env["FASTCODE_SKILLS_REGISTRY"], state.skillsRegistry);
            if (!registry)
                return { message: "No skills registry configured. Set one with `/skills registry <url>` or FASTCODE_SKILLS_REGISTRY." };
            if (rest.length === 0)
                return { message: "Usage: /skills search <query>" };
            const hits = await searchRegistry(rest.join(" "), registry);
            if (hits.length === 0) {
                return { message: `No skills found for "${rest.join(" ")}".` };
            }
            const lines = [`Skills matching "${rest.join(" ")}":`];
            for (const h of hits.slice(0, 20)) {
                lines.push(`  • ${h.slug}  — ${truncate(h.description ?? "", 80)}`);
            }
            lines.push("");
            lines.push("Install with `/skills install <slug>`.");
            return { message: lines.join("\n") };
        }
        if (sub === "install" || sub === "add") {
            if (rest.length === 0)
                return { message: "Usage: /skills install <name|owner/repo|url>" };
            const force = rest.includes("--force");
            const spec = rest.filter((r) => r !== "--force").join(" ");
            try {
                const skill = await installSkill(spec, { registry: state.skillsRegistry, force });
                return {
                    message: `Installed skill "${skill.name}" → ${skill.path}\n${truncate(skill.description, 200)}\n\nEnable with /skills enable ${skill.name}`,
                };
            }
            catch (err) {
                return { message: `Install failed: ${err.message}` };
            }
        }
        if (sub === "uninstall" || sub === "remove" || sub === "rm") {
            if (rest.length === 0)
                return { message: "Usage: /skills uninstall <name>" };
            const ok = uninstallSkill(rest[0]);
            if (ok)
                actions.disableSkill(rest[0]);
            return { message: ok ? `Uninstalled "${rest[0]}".` : `No skill named "${rest[0]}".` };
        }
        if (sub === "enable" || sub === "use") {
            if (rest.length === 0) {
                const installed = listInstalledSkills();
                if (installed.length === 0)
                    return { message: "No skills installed. Try `/skills install <name>`." };
                return {
                    message: "Choose a skill to enable.",
                    picker: {
                        title: "Enable skill",
                        current: state.enabledSkills[0],
                        items: installed.map((skill) => ({
                            value: skill.name,
                            label: skill.name,
                            hint: skill.integrity === "ok" ? truncate(skill.description, 60) : skill.integrity,
                        })),
                        onSelect: (value) => {
                            const skill = getSkill(value);
                            if (!skill) {
                                actions.pushSystemMessage(`Skill "${value}" is not installed.`);
                                return;
                            }
                            const problem = integrityProblem(skill);
                            if (problem) {
                                actions.pushSystemMessage(problem);
                                return;
                            }
                            actions.enableSkill(skill.name);
                            actions.pushSystemMessage(`Enabled skill "${skill.name}".`);
                        },
                    },
                };
            }
            const skill = getSkill(rest[0]);
            if (!skill)
                return { message: `Skill "${rest[0]}" is not installed.` };
            const problem = integrityProblem(skill);
            if (problem)
                return { message: problem };
            actions.enableSkill(skill.name);
            return { message: `Enabled skill "${skill.name}".` };
        }
        if (sub === "disable" || sub === "off") {
            if (rest.length === 0) {
                const installed = listInstalledSkills();
                if (installed.length === 0)
                    return { message: "No skills installed." };
                return {
                    message: "Choose a skill to disable.",
                    picker: {
                        title: "Disable skill",
                        current: state.enabledSkills[0],
                        items: installed.map((skill) => ({
                            value: skill.name,
                            label: skill.name,
                            hint: state.enabledSkills.includes(skill.name) ? "enabled" : "disabled",
                        })),
                        onSelect: (value) => {
                            actions.disableSkill(value);
                            actions.pushSystemMessage(`Disabled skill "${value}".`);
                        },
                    },
                };
            }
            actions.disableSkill(rest[0]);
            return { message: `Disabled skill "${rest[0]}".` };
        }
        if (sub === "info" || sub === "show") {
            if (rest.length === 0) {
                const installed = listInstalledSkills();
                if (installed.length === 0)
                    return { message: "No skills installed." };
                return {
                    message: "Choose a skill to inspect.",
                    picker: {
                        title: "Skill info",
                        items: installed.map((skill) => ({
                            value: skill.name,
                            label: skill.name,
                            hint: truncate(skill.description, 60),
                        })),
                        onSelect: (value) => {
                            const skill = getSkill(value);
                            if (!skill) {
                                actions.pushSystemMessage(`Skill "${value}" is not installed.`);
                                return;
                            }
                            actions.pushSystemMessage(`# ${skill.name}\n_${skill.description}_\n\nSource: ${skill.source}\n\n---\n\n${skill.body}`);
                        },
                    },
                };
            }
            const skill = getSkill(rest[0]);
            if (!skill)
                return { message: `Skill "${rest[0]}" is not installed.` };
            const head = `# ${skill.name}\n_${skill.description}_\n\nSource: ${skill.source}\n\n---\n\n`;
            return { message: head + skill.body };
        }
        if (sub === "verify") {
            const confirm = rest.includes("--confirm") || rest.includes("--yes");
            const all = rest.includes("--all");
            const names = rest.filter((entry) => !entry.startsWith("-"));
            if (!all && names.length === 0)
                return { message: "Usage: /skills verify <name> --confirm   (or /skills verify --all --confirm)" };
            if (!confirm) {
                return { message: `Re-baselining ${all ? "all skills" : names.join(", ")} trusts the current files as the new baseline. ` +
                        "Re-run the same command with --confirm to proceed." };
            }
            const results = rebaselineSkills(all ? undefined : names);
            if (results.length === 0)
                return { message: "No matching installed skills to verify." };
            const lines = ["Skill integrity re-baselined:"];
            for (const result of results)
                lines.push(result.ok ? `  • ${result.name}: locked` : `  • ${result.name}: FAILED — ${result.warning ?? "unknown error"}`);
            return { message: lines.join("\n") };
        }
        if (sub === "registry") {
            if (rest.length === 0) {
                const registry = resolveRegistry(process.env["FASTCODE_SKILLS_REGISTRY"], state.skillsRegistry);
                return { message: registry
                        ? `Skills registry: ${registry}`
                        : "No skills registry configured. Set one with `/skills registry <url>` or FASTCODE_SKILLS_REGISTRY." };
            }
            // Mutate via AppActions so the in-memory React state stays in sync —
            // direct saveConfig() would be silently overwritten by the next state
            // change because app.tsx persists in-memory config on every update.
            actions.setSkillsRegistry(rest[0]);
            return { message: `Skills registry set to ${rest[0]}.` };
        }
        return {
            message: "Unknown subcommand. Try: list, search, install, uninstall, enable, disable, info, verify, registry.",
        };
    },
};
function truncate(s, n) {
    if (s.length <= n)
        return s;
    return s.slice(0, n - 1) + "…";
}
function integrityProblem(skill) {
    if (skill?.integrity === "ok")
        return undefined;
    const reason = skill?.integrity === "drift" ? "content drift detected" : "no integrity baseline";
    return `Skill "${skill?.name}" is disabled (${reason}). Run /skills verify ${skill?.name} --confirm to re-baseline.`;
}
