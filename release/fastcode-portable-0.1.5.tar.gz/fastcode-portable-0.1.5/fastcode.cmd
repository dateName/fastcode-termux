@echo off
setlocal
set "DIR=%~dp0"
node "%DIR%package/bin/fastcode.mjs" %*
